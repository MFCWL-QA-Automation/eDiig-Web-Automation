package com.ediig.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class wait {
	private static WebDriver driver;
	private static WebElement element;
	private static WebDriverWait wait = new WebDriverWait(driver, 20);
	 

	/*
	 * public static void waitclick(WebDriver abc,String selectsellername4 ) {
	 * 
	 * 
	 * WebDriverWait wait = new WebDriverWait(abc, 10);
	 * 
	 * wait.until(ExpectedConditions.elementToBeClickable(By.xpath(selectsellername4
	 * )));
	 * 
	 * }
	 */
	public static void waitForElement(WebElement webElement) {
        element = webElement;
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

}

