package com.ediig.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MyquotesPage {
	
	
	@FindBy(how = How.XPATH, using = ("//a[text()='My Quotes']"))
	static WebElement myquotestab;
	
	@FindBy(how = How.XPATH, using = ("(//input[@class='select-dropdown'])[1]"))
	private static WebElement myquoteschooseSeller;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller')]/following::li[3]"))
	static WebElement selectsellername1;
	
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller')]/following::li[4]"))
	static WebElement selectsellername2;
	
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller')]/following::li[7]"))
	static WebElement selectsellername3;
	
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller')]/following::li[8]"))
	static WebElement selectsellername4;
	
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller')]/following::li[11]"))
	static WebElement selectsellername5;
	
	@FindBy(how = How.XPATH, using = ("	(//label[text()='Select all'])[1]"))
	static WebElement selectall;
	
	@FindBy(how = How.XPATH, using = ("(//input[@class='select-dropdown'])[2]"))
	static WebElement myquoteschoosecommunity;
    
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Community')]/following::li[3]"))
	static WebElement myquotesCommunity1;
	
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Community')]/following::li[4]"))
	static WebElement myquotesCommunity2;
	
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Community')]/following::li[5]"))
	static WebElement myquotesCommunity3;
	
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Community')]/following::li[6]"))
	static WebElement myquotesCommunity4;
	
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Community')]/following::li[7]"))
	static WebElement myquotesCommunity5;
	
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller')]"))
	static WebElement clicktext;
	
	@FindBy(how = How.XPATH, using = ("//a[contains(text(),'Print')]"))
	static WebElement print1;
	
	@FindBy(how = How.XPATH, using = ("//th[@id='vehicleImage']"))
	static WebElement sortimage;
	
	@FindBy(how = How.XPATH, using = ("//th[@id='listingId']"))
	static WebElement sortlistingId;
	
	@FindBy(how = How.XPATH, using = ("//th[@id='agreementNo']"))
	static WebElement sortagreementNo;
	
	@FindBy(how = How.XPATH, using = ("//th[@id='regNo']"))
	static WebElement sortregNo;
	
	@FindBy(how = How.XPATH, using = ("//th[@id='makeAndModel']"))
	static WebElement sortmakeAndModel;
	
	@FindBy(how = How.XPATH, using = ("//th[@id='clientName']"))
	static WebElement sortclientName;
	
	@FindBy(how = How.XPATH, using = ("//th[@id='status']"))
	static WebElement sortstatus;
	
	@FindBy(how = How.XPATH, using = ("//th[@id='myHighestQuote']"))
	static WebElement sortsmyHighestQuote;
	
	@FindBy(how = How.XPATH, using = ("//th[@id='quoteDateAndTime']"))
	static WebElement sortquoteDateAndTime;
	
	@FindBy(how = How.XPATH, using = ("//th[@id='vehiclePrint']"))
	static WebElement sortvehiclePrint;



	private static WebDriver driver;

	public MyquotesPage(WebDriver driver) {
		this.driver = driver;}

	public static void enterintomyQuotes() throws InterruptedException {
		Thread.sleep(3000);
		MyquotesPage.myquotestab.click();	
		Thread.sleep(1000);
	}
	
	
public static void myquotechoosefilters() throws InterruptedException {
	//choose seller name
	Thread.sleep(1000);
	MyquotesPage.myquoteschooseSeller.click();
	Thread.sleep(1000);
	MyquotesPage.selectsellername1.click();
	Thread.sleep(1000);
	MyquotesPage.selectsellername2.click();
	Thread.sleep(1000);
	MyquotesPage.selectsellername3.click();
	Thread.sleep(1000);
	MyquotesPage.selectsellername4.click();
	Thread.sleep(1000);
	MyquotesPage.selectsellername5.click();
	Thread.sleep(1000);
	MyquotesPage.clicktext.click();
	Thread.sleep(1000);
	
	//choose my quotes choose community
	MyquotesPage.myquoteschoosecommunity.click();
	Thread.sleep(1000);
	MyquotesPage.myquotesCommunity1.click();
	Thread.sleep(1000);
	MyquotesPage.myquotesCommunity2.click();
	Thread.sleep(1000);
	MyquotesPage.myquotesCommunity3.click();
	Thread.sleep(1000);
	MyquotesPage.myquotesCommunity4.click();
	Thread.sleep(1000);
	MyquotesPage.myquotesCommunity5.click();
	Thread.sleep(1000);
	MyquotesPage.clicktext.click();
	Thread.sleep(1000);
}
	public static void print() throws AWTException, InterruptedException {
		driver.switchTo().activeElement();
	MyquotesPage.print1.click();
	Thread.sleep(5000);
	Robot r = new Robot();
	r.keyPress(KeyEvent.VK_ESCAPE);
	r.keyRelease(KeyEvent.VK_ESCAPE);
	Thread.sleep(5000);
	System.out.println(" print");
	driver.navigate().back();
}
	
	
	public static void sorting() throws InterruptedException {
		Thread.sleep(2000);
		//MyquotesPage.sortimage.click();
		Thread.sleep(1000);
		//MyquotesPage.sortlistingId.click();
		
		MyquotesPage.sortagreementNo.click();
		Thread.sleep(2000);
		MyquotesPage.sortregNo.click();
		Thread.sleep(2000);
		MyquotesPage.sortmakeAndModel.click();
		Thread.sleep(2000);
		MyquotesPage.sortclientName.click();
		Thread.sleep(1000);
		MyquotesPage.sortstatus.click();
		Thread.sleep(2000);
		MyquotesPage.sortsmyHighestQuote.click();
		Thread.sleep(1000);
		MyquotesPage.sortquoteDateAndTime.click();
		Thread.sleep(2000);
		
		
	}
}
