package com.ediig.pages;

import java.io.File;
import java.io.FileFilter;
import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import org.junit.Assert;

public class SaleCalenderPage {
	final static Logger log = Logger.getLogger(SaleCalenderPage.class.getName());

	WebDriver driver;

	@FindBy(how = How.XPATH, using = "//a[text()='Sale Calendar']")
	static WebElement saleCalenderTab;

	@FindBy(how = How.XPATH, using = "//th[@id='thCategory']")
	static WebElement categoryUpOnSaleCalendarClick;

	@FindBy(how = How.XPATH, using = ("//div[@class='select-wrapper mdb-select']/ul/li[3]"))
	static WebElement showEntries;

	@FindBy(how = How.XPATH, using = "//td[@class='sorting_1']")
	static WebElement saleListDownload;

	// static WebElement chooseLocationDropdown;

	@FindBy(how = How.XPATH, using = ("//label[text()='Location']/../div/input"))
	private static WebElement chooseLocationDropdown;

	// select location elements
	@FindBy(how = How.XPATH, using = ("(//span[@class='filtrable'])[3]"))
	static WebElement location1;

	@FindBy(how = How.XPATH, using = ("(//span[@class='filtrable'])[5]"))
	static WebElement location2;

	@FindBy(how = How.XPATH, using = ("(//span[@class='filtrable'])[9]"))
	static WebElement location3;

	@FindBy(how = How.XPATH, using = ("(//span[@class='filtrable'])[15]"))
	static WebElement location4;

	@FindBy(how = How.XPATH, using = ("(//span[@class='filtrable'])[18]"))
	static WebElement location5;

	// choose seller dropdown
	@FindBy(how = How.XPATH, using = ("//label[text()='Seller Name']/../div/input"))
	static WebElement chooseSellerName;

	// choose seller name

	@FindBy(how = How.XPATH, using = ("//label[text()='Seller Name']/../div/ul/li[4]"))
	static WebElement seller1;

	@FindBy(how = How.XPATH, using = ("//label[text()='Seller Name']/../div/ul/li[7]"))
	static WebElement seller2;

	@FindBy(how = How.XPATH, using = ("//label[text()='Seller Name']/../div/ul/li[9]"))
	static WebElement seller3;

	// choose category dropdown
	@FindBy(how = How.XPATH, using = ("//label[text()='Category']/../div/input"))
	static WebElement chooseCategoroyDropdown;

	// select category elements
	@FindBy(how = How.XPATH, using = ("//label[text()='Category']/../div/ul/li[3]"))
	static WebElement category1;

	@FindBy(how = How.XPATH, using = ("//label[text()='Category']/../div/ul/li[4]"))
	static WebElement category2;

	@FindBy(how = How.XPATH, using = ("//label[text()='Category']/../div/ul/li[6]"))
	static WebElement category3;

	@FindBy(how = How.XPATH, using = ("//label[text()='Category']/../div/ul/li[7]"))
	static WebElement category4;

	// Choose auction type elements
	@FindBy(how = How.XPATH, using = ("//label[text()='Auction Type']/../div/input"))
	static WebElement chooseAuctiontype;

	@FindBy(how = How.XPATH, using = ("//span[text()=' Offline Auctions   ']"))
	static WebElement OfflineAuctions;

	// click on filter
	@FindBy(how = How.XPATH, using = ("//div[@id='saleCalendarTabel_info']"))
	static WebElement clickText;

	// reset all
	@FindBy(how = How.XPATH, using = ("//span[@class='btn btn-blue-grey btn-sm_small my-0 waves-effect waves-light restFilter']"))
	static WebElement resetall;

	// for sorting
	@FindBy(how = How.XPATH, using = ("//th[@id='thCategory']"))
	static WebElement sortCategory;

	@FindBy(how = How.XPATH, using = ("//th[@id='thEventType']"))
	static WebElement sortEventType;

	@FindBy(how = How.XPATH, using = ("//th[@id='thSellerName']"))
	static WebElement sortSellerName;

	@FindBy(how = How.XPATH, using = ("//th[@id='thLocation']"))
	static WebElement sortLocation;

	@FindBy(how = How.XPATH, using = ("//th[@id='thSaleDate']"))
	static WebElement sortSaleDate;

	@FindBy(how = How.XPATH, using = ("//th[@id='thDetails']"))
	static WebElement sortDetails;

	@FindBy(how = How.XPATH, using = ("//div[@id='saleCalendarTabel_info']"))
	static WebElement showingentries;
	
	

	String categoryValue1;
	String categoryValue2;
	String categoryValue3;
	String categoryValue4;

	String locationValue1;
	String locationValue2;
	String locationValue3;
	String locationValue4;

	String sellerValue1;
	String sellerValue2;
	String sellerValue3;

	public SaleCalenderPage(WebDriver driver) {
		this.driver = driver;
	}

	public static void clickSaleCalender() throws Exception {
		Thread.sleep(2000);
		saleCalenderTab.click();

		// Generic.elementFound(categoryUpOnSaleCalendarClick);
	}

	public  void chooseLocationDropdown() throws InterruptedException {
		Thread.sleep(2000);
		chooseLocationDropdown.click();
		Thread.sleep(2000);
		locationValue1 = location1.getText();
		Thread.sleep(1000);
		location1.click();
		Thread.sleep(1000);
		locationValue2 = location2.getText();
		Thread.sleep(1000);
		location2.click();
		Thread.sleep(1000);
		locationValue3 = location3.getText();
		Thread.sleep(1000);
		location3.click();
		Thread.sleep(1000);
		locationValue4 = location4.getText();
		Thread.sleep(1000);
		location4.click();
		Thread.sleep(1000);
		location5.click();
		clickText.click();
		Thread.sleep(2000);
	}

	public void chooseCategoryDropdown() throws InterruptedException {
		chooseCategoroyDropdown.click();
		Thread.sleep(2000);
		categoryValue1 = category1.getText();
		Thread.sleep(1000);
		category1.click();
		Thread.sleep(1000);
		categoryValue2 = category2.getText();
		Thread.sleep(1000);
		category2.click();
		Thread.sleep(1000);
		categoryValue3 = category3.getText();
		Thread.sleep(1000);
		category3.click();
		Thread.sleep(1000);
		categoryValue4 = category4.getText();
		Thread.sleep(1000);
		category4.click();
		Thread.sleep(1000);
		clickText.click();
		Thread.sleep(1000);
	}

	public void chooseSellerName() throws InterruptedException {
		chooseSellerName.click();
		Thread.sleep(1000);
		sellerValue1 = seller1.getText();
		Thread.sleep(1000);
		seller1.click();
		Thread.sleep(1000);
		sellerValue2 = seller2.getText();
		Thread.sleep(1000);
		seller2.click();
		Thread.sleep(1000);
		sellerValue3 = seller3.getText();
		Thread.sleep(1000);
		seller3.click();
		Thread.sleep(3000);
		clickText.click();
	}

	public void chooseAuctiontype() throws InterruptedException {
		Thread.sleep(3000);
		chooseAuctiontype.click();
		Thread.sleep(1000);
		OfflineAuctions.click();
		Thread.sleep(2000);
		clickText.click();
		Thread.sleep(1000);
	}

	public void showingentries() throws InterruptedException {
		log.info(SaleCalenderPage.showingentries.getText());
		Thread.sleep(1000);
	}

	public void saleListDownload() throws InterruptedException {
		Thread.sleep(2000);
		saleListDownload.click();
	}

	public void filterDataCategoryValidation() {
		List<WebElement> filtercategoryElementsInATable = driver.findElements(By.xpath("(//tr[@role='row'])[*]/td[1]"));
		for (int i = 1; i < filtercategoryElementsInATable.size(); i++) {
			String text = filtercategoryElementsInATable.get(i).getText();
			log.info(String.format("text is %s and categoryValue1 is %s, categoryValue2 is %s, categoryValue3 is %s ", text, categoryValue1, categoryValue2, categoryValue3));
			if (text.equalsIgnoreCase(categoryValue1) || (text.equalsIgnoreCase(categoryValue2) || (text.equalsIgnoreCase(categoryValue3)))) {
				log.info("Selected Category appears on Response");
			} else {
				Assert.fail("Selected Category didnt get select");
			}
		}
	}

	public  void filterDataLocationValidation() {
		List<WebElement> LocationElementsInATable = driver.findElements(By.xpath("(//tr[@role='row'])[*]/td[4]"));
		for (int i = 1; i < LocationElementsInATable.size(); i++) {
			String text = LocationElementsInATable.get(i).getText();
			log.info(String.format("text is %s and locationValue1 is %s, locationValue2 is %s, locationValue3 is %s ", text, locationValue1, locationValue2, locationValue3));
			if (text.equalsIgnoreCase(locationValue1) || text.equalsIgnoreCase(locationValue2) || text.equalsIgnoreCase(locationValue3)) {
				log.info("Selected Location appears on Response");
			} else {
				Assert.fail("Selected Location didnt get select");
			}
		}
	}

	public void filterDataSellerNameValidation() {
		List<WebElement> SellerElementsInATable = driver.findElements(By.xpath("(//tr[@role='row'])[*]/td[3]"));
		for (int i = 1; i < SellerElementsInATable.size(); i++) {
			String text = SellerElementsInATable.get(i).getText();
			log.info(String.format("text is %s and sellerValue1 is %s, sellerValue2 is %s, sellerValue3 is %s ", text, sellerValue1, sellerValue2, sellerValue3));
			if (text.equalsIgnoreCase(sellerValue1)|| text.equalsIgnoreCase(sellerValue2) || text.equalsIgnoreCase(sellerValue3)) {
				log.info("Selected Seller Name appears on Response");
			} else {
				Assert.fail("Selected seller didnt get select");
			}
		}
	}

	public void sortingdata() throws InterruptedException {
		sortCategory.click();
		Thread.sleep(2000);
		sortEventType.click();
		Thread.sleep(2000);
		sortSellerName.click();
		Thread.sleep(2000);
		sortLocation.click();
		Thread.sleep(2000);
		sortSaleDate.click();
		Thread.sleep(2000);
		sortDetails.click();
	}

	public void showingentriesno() throws InterruptedException {
		log.info(SaleCalenderPage.showingentries.getText());
	}

	public void resetAll() {
		System.out.println("clickesd reset all");
		resetall.click();
	}

}

/*
 * List<WebElement> elements =
 * driver.findElements(By.xpath(("//tr[@role='row']/td[1]"))); for (int i = 0; i
 * < elements.size(); i++) { String actualCategoryAfterFilterSelection =
 * elements.get(i).getText(); if
 * (actualCategoryAfterFilterSelection.equalsIgnoreCase("2w")) {
 * Assert.assertEquals("2w is selected", "2w",
 * actualCategoryAfterFilterSelection); } else if
 * (actualCategoryAfterFilterSelection.equalsIgnoreCase("2w" + "/" + "4w")) {
 * Assert.assertEquals("2w/4w is selected", "2w/4w",
 * actualCategoryAfterFilterSelection); }
 */

/*
 * public void filterDataLocationValidation() { List<WebElement> elements =
 * driver.findElements(By.xpath(("//tr[@role='row']/td[4]"))); for (int i = 0; i
 * < elements.size(); i++) { String actualLocationAfterFilterSelection =
 * elements.get(i).getText(); if
 * (actualLocationAfterFilterSelection.equalsIgnoreCase("ADONI")) {
 * Assert.assertEquals("Adoni is selected", "ADONI",
 * actualLocationAfterFilterSelection); } else if
 * (actualLocationAfterFilterSelection.equalsIgnoreCase("BANGALORE")) {
 * Assert.assertEquals("Bangalore is selected", "BANGALORE",
 * actualLocationAfterFilterSelection); } else if
 * (actualLocationAfterFilterSelection.equalsIgnoreCase("MYSORE")) {
 * Assert.assertEquals("MYSORE is selected", "MYSORE",
 * actualLocationAfterFilterSelection); } else if
 * (actualLocationAfterFilterSelection.equalsIgnoreCase("HYDERABAD")) {
 * Assert.assertEquals("HYDERABAD is selected", "HYDERABAD",
 * actualLocationAfterFilterSelection); } else if
 * (actualLocationAfterFilterSelection.equalsIgnoreCase("AHMEDABAD")) {
 * Assert.assertEquals("AHMEDABAD is selected", "AHMEDABAD",
 * actualLocationAfterFilterSelection); } } }
 * 
 * public void filterDataSellerNameValidation() { List<WebElement> elements =
 * driver.findElements(By.xpath(("//tr[@role='row']/td[3]"))); for (int i = 0; i
 * < elements.size(); i++) { String actualSellerNameAfterFilterSelection =
 * elements.get(i).getText(); if
 * (actualSellerNameAfterFilterSelection.equalsIgnoreCase("BAJAJ AUTO FINANCE"))
 * { Assert.assertEquals("BajajAutoFinance is selected", "BAJAJ AUTO FINANCE",
 * actualSellerNameAfterFilterSelection); } else if
 * (actualSellerNameAfterFilterSelection.equalsIgnoreCase("ALD AUTOMOTIVE")) {
 * Assert.assertEquals("ALD AUTOMOTIVE is selected", "ALD AUTOMOTIVE",
 * actualSellerNameAfterFilterSelection);
 * 
 * } } }
 * 
 * 
 * 
 * 
 * 
 * /* public void downloadFileValidation() { File dir = new File("Downloads");
 * File[] matchingFiles = dir.listFiles(new FileFilter() {
 * 
 * @Override public boolean accept(File pathname) { return
 * pathname.getName().contains("1575532749136"); } }); }
 */

//// span[@class='btn btn-blue-grey btn-sm_small my-0 waves-effect waves-light
//// restFilter']

// public void sellerName() {
// chooseLocationDropdown.click();
// String locationName = "Adoni";
// driver.findElement(By.xpath("//ul[contains(@id,
// 'select-options-')]/*/span[text()=' " + locationName + " ']"))
// .click();
// Generic.selectDropdownByText(chooseLocationDropdown, 1);
