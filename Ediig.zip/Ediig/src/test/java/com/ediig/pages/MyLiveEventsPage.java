package com.ediig.pages;

import java.util.ArrayList;

import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.junit.Assert;

public class MyLiveEventsPage {
	
	private static final Logger log = Logger.getLogger(MyLiveEventsPage.class.getName());

	static Actions actions;
	

	@FindBy(how = How.XPATH, using = ("//a[text()='My Live Events']"))
	static WebElement myliveeventstab;

	// choose seller name
	@FindBy(how = How.XPATH, using = ("//label[text()='Seller Name']/../div/input"))
	static WebElement mylivechooseSellerName;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller Name')]/following::li[3]"))
	static WebElement selectsellername1;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller Name')]/following::li[5]"))
	static WebElement selectsellername2;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller Name')]/following::li[4]"))
	static WebElement selectsellername3;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller Name')]/following::li[8]"))
	static WebElement selectsellername4;

	// choose location
	@FindBy(how = How.XPATH, using = ("//label[text()='Location']/../div/input"))
	static WebElement mylivechooseLocationDropdown;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Location')]/following::li[3]"))
	static WebElement location1;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Location')]/following::li[4]"))
	static WebElement location2;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Location')]/following::li[5]"))
	static WebElement location3;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Location')]/following::li[8]"))
	static WebElement location4;

	// choose event type
	//@FindBy(how = How.XPATH, using = ("//label[text()='Event Type']/../div/input"))
	//@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Event Type')]/following::li[1]"))
	@FindBy(how = How.XPATH, using = ("(//input[@class='select-dropdown'])[3]"))
	//label[contains(text(),'Event Type')]/following::li[1]
	static WebElement mylivechooseEventType;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Event Type')]/following::li[2]"))
	static WebElement alleventtype;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Event Type')]/following::li[3]"))
	static WebElement narmaleventtype1;

	@FindBy(how = How.XPATH, using = ("//span[@class='btn btn-blue-grey btn-sm_small my-0 waves-effect waves-light restFilter']"))
	static WebElement myliveresetall;

	@FindBy(how = How.XPATH, using = ("(//table[@id='quoteEventTabel']/tbody//a[not(contains(text(), 'eT-'))][1])[1]"))
	static WebElement openliveEvent;
	
	/*@FindBy(how = How.XPATH, using = ("(//tr[@role='row']/td)[1]"))
	static WebElement openliveEvent1;

	@FindBy(how = How.XPATH, using = ("(//tr[@role='row']/td)[4]"))
	static WebElement openliveEvent2;

	@FindBy(how = How.XPATH, using = ("(//tr[@role='row']/td)[7]"))
	static WebElement openliveEvent3;

	@FindBy(how = How.XPATH, using = ("(//tr[@role='row']/td)[10]"))
	static WebElement openliveEvent4;*/

	/*
	 * @FindBy(how = How.XPATH, using =
	 * ("(//*[text()='Inspected! Proceed to Bid'])[2]")) static WebElement
	 * inspectedproceedtoBid2;
	 */
	@FindBy(how = How.XPATH, using = ("(//label[@class='custom-control-label'])[3]"))
	static WebElement inspectedproceedtoBid2;

	@FindBy(how = How.XPATH, using = ("(//label[@class='custom-control-label'])[1]"))
	static WebElement inspectedproceedtoBid1;

	@FindBy(how = How.XPATH, using = ("//a[@class='btn btn-primary btn-sm  waves-effect waves-light']/following::button[1]"))
	static WebElement Quotenow1;

	@FindBy(how = How.XPATH, using = ("(//*[text()='Inspected! Proceed to Bid'])[2]"))
	static WebElement closebid;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[3]"))
	static WebElement addtowatchlist1;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[4]"))
	static WebElement addtowatchlist2;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[5]"))
	static WebElement addtowatchlist3;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[6]"))
	static WebElement addtowatchlist4;

	@FindBy(how = How.XPATH, using = ("(//div[@class=\"row p-2 m-0\"])"))
	static WebElement vehiclesresponcelist;

	@FindBy(how = How.XPATH, using = ("//input[@id='bidAmt2']"))
	static WebElement enteramount;

	@FindBy(how = How.XPATH, using = ("(//div[@class='dataTables_info'])[1]"))
	static WebElement clicksidetest;

	@FindBy(how = How.XPATH, using = ("//input[@id='bidAmt1']"))
	static WebElement bidamount2;
	
	@FindBy(how = How.XPATH, using = ("//input[@id='bidAmt2']"))
	static WebElement bidamount3;


	@FindBy(how = How.XPATH, using = ("//input[@id='bidAmt0']"))
	static WebElement bidamount1;

	@FindBy(how = How.XPATH, using = ("//input[@id='search']"))
	static WebElement mylivesearch;

	@FindBy(how = How.XPATH, using = ("(//p[@class='mb-1'])[1]"))
	static WebElement eventname;

	@FindBy(how = How.XPATH, using = ("(//span[text()='Reg.No']//..)[1]"))
	static WebElement regno;

	@FindBy(how = How.XPATH, using = ("(//button[@class='btn btn-primary btn-sm'])[2]"))
	static WebElement closeinvalid;

	@FindBy(how = How.XPATH, using = ("(//button[@type='button'])[3]"))
	static WebElement searchbutton;

	@FindBy(how = How.XPATH, using = ("//a[@class='btn btn-primary btn-sm  waves-effect waves-light']"))
	static WebElement refresh;

	@FindBy(how = How.XPATH, using = ("//button[@id='bidPopUpModelSaveBtn']"))
	static WebElement savechangesbutton;

	@FindBy(how = How.XPATH, using = ("	(//button[@class='close'])[6]"))
	static WebElement crossIcon2;

	@FindBy(how = How.XPATH, using = ("(//a[contains(text(),'eT-')])[1]"))
	static WebElement openEtliveEvent;
	
	@FindBy(how = How.XPATH, using = ("//*[@id=\"bidPopModel\"]/div/div/div[3]/button[1]"))
	static WebElement closechildwindow;
	
	

	private static WebDriver driver;

	public MyLiveEventsPage(WebDriver driver) {
		this.driver = driver;
	}
	
	
		
	public static void choosefilters() throws InterruptedException {
		myliveeventstab.click();
		Thread.sleep(2000);
		mylivechooseSellerName.click();
		Thread.sleep(2000);
		selectsellername1.click();
		Thread.sleep(1000);
		selectsellername2.click();
		Thread.sleep(1000);
		selectsellername3.click();
		Thread.sleep(1000);
		//selectsellername4.click();
		Thread.sleep(2000);
		// wait.waitForElement(selectsellername4);
		clicksidetest.click();
		Thread.sleep(2000);

		/*
		 * WebElement element = null; WebDriverWait wait = new WebDriverWait(driver, 5);
		 * element = wait.until(ExpectedConditions.elementToBeClickable(clicksidetest));
		 * element.click();
		 */

		mylivechooseLocationDropdown.click();
		location1.click();
		Thread.sleep(1000);
		location2.click();
		Thread.sleep(1000);
		location3.click();
		Thread.sleep(1000);
		// location4.click();
		Thread.sleep(1000);
		clicksidetest.click();
		Thread.sleep(1000);

		mylivechooseEventType.click();
		Thread.sleep(1000);
		narmaleventtype1.click();
		Thread.sleep(1000);
		clicksidetest.click();
		Thread.sleep(4000);
		
	}
		public static void quotenow() throws InterruptedException {
			
		Thread.sleep(2000);
		//myliveeventstab.click();
		Thread.sleep(2000);
		openliveEvent.click();
		Thread.sleep(3000);
		Quotenow1.click();
		Thread.sleep(2000);
		Alert alertok = driver.switchTo().alert();
		String alertText = alertok.getText();
		System.out.println("Alert data: " + alertText);
		alertok.accept();
		Thread.sleep(3000);

		inspectedproceedtoBid1.click();
		Thread.sleep(2000);
		Quotenow1.click();
		Thread.sleep(2000);
		Alert Confirmbid = driver.switchTo().alert();
		String ConfirmalertText = Confirmbid.getText();
		System.out.println("Alert data: " + ConfirmalertText);
		Thread.sleep(2000);
		Confirmbid.accept();
		Thread.sleep(3000);

		Alert successbid = driver.switchTo().alert();
		String successbidalertText = successbid.getText();
		System.out.println("Alert data: " + successbidalertText);
		Thread.sleep(2000);
		successbid.accept();
		System.out.println("bid submited sucsessfully");
		Thread.sleep(1000);
		}
		
		public static void invalidamount() throws InterruptedException{
		  Thread.sleep(2000); 
		 inspectedproceedtoBid1.click(); 
		 // driver.findElement(By.xpath("(//label[@class='custom-control-label'])[3]"));
		  Thread.sleep(2000); 
		  bidamount1.clear();
		  Thread.sleep(1000);
		  bidamount1.sendKeys("xyz000"); 
		  Thread.sleep(1000); 
		  Quotenow1.click();
		  //closeinvalid.click(); //savechangesbutton.click(); //crossIcon2.click();
		  //crossIcon2.equals(successbidalertText);
		  Alert invalidamount = driver.switchTo().alert();
		  String invalidamountalertText = invalidamount.getText();
		  System.out.println("Alert data: " +
		  invalidamountalertText); 
		  Thread.sleep(2000); 
		  invalidamount.accept();
		 
	}
		
		public static void multiQuotes() throws InterruptedException {
			
			Thread.sleep(2000);
			inspectedproceedtoBid1.click();
			Thread.sleep(2000);
			inspectedproceedtoBid2.click();
			Thread.sleep(2000);
			Quotenow1.click();
			Thread.sleep(2000);
			Alert Confirmbid = driver.switchTo().alert();
			String ConfirmalertText = Confirmbid.getText();
			System.out.println("Alert data: " + ConfirmalertText);
			Thread.sleep(2000);
			Confirmbid.accept();
			Thread.sleep(3000);

			Alert successbid = driver.switchTo().alert();
			String successbidalertText = successbid.getText();
			System.out.println("Alert data: " + successbidalertText);
			Thread.sleep(2000);
			successbid.accept();
			System.out.println("bid submited sucsessfully");
			Thread.sleep(1000);
			}
			

	public static void addToWatchlist() throws InterruptedException {
		List<String> regNumList = new ArrayList<String>();

		List<WebElement> response = driver.findElements(By.xpath("//div[contains(@class, 'shdhover')]"));
		int i = 1;
		int count = 3;
		for (WebElement element : response) {
			List<WebElement> spans = element.findElements(By.tagName("li"));

			WebElement regNo = spans.stream().filter(ele -> ele.getText().contains("Reg.No")).findAny().get();

			List<WebElement> buttons = element.findElements(By.tagName("button"));
			if (!buttons.isEmpty()) {
				regNumList.add(regNo.getText().substring(8));
				buttons.get(0).click();
			}

			if (i == count)
				break;
			i++;
		}
		
		log.info("Reg No's added to watch list "+ regNumList);
		
        WebElement watchlist=driver.findElement(By.xpath("//a[text()='My Watch List']"));
		watchlist.click();
		Thread.sleep(2000);

		List<WebElement> wishListResponse = driver.findElements(By.xpath("//div[contains(@class, 'shdhover')]"));
		List<String> wishedRegNumList = new ArrayList<String>();
		for (WebElement element : wishListResponse) {
			List<WebElement> spans = element.findElements(By.tagName("li"));
			WebElement regNo = spans.stream().filter(ele -> ele.getText().contains("reg.No")).findAny().get();
			wishedRegNumList.add(regNo.getText().substring(6));
		}
		
		log.info("All the Reg No's in wish list "+ wishedRegNumList); 

		Assert.assertTrue(wishedRegNumList.containsAll(regNumList));

	}
	
	public static void MyLiveEventEtquotepage() throws InterruptedException {
		myliveeventstab.click();
		Thread.sleep(3000);
		openEtliveEvent.click();
		Thread.sleep(2000);
		inspectedproceedtoBid1.click();
		Thread.sleep(2000);
		Quotenow1.click();
		String Parentwindow = driver.getWindowHandle();
		for(String Subwindow:driver.getWindowHandles()){
			driver.switchTo().window(Subwindow);
			Thread.sleep(3000);
			closechildwindow.click();	
			Thread.sleep(1000);
			myliveeventstab.click();
		}
				
		}
	
	
	
	

	// (//button[@class='btn btn-primary btn-sm'])[2]

	// save list which we adding to wish list

	/*
	 * for(int i=0;i<sellerList.size();i++){ int random = getRandomNumber(1,5);
	 * sellerFilters.add(sellerList.get(random).getText());
	 * sellerList.get(random).click(); elementClick(clickwhitespace);
	 */

	/*
	 * String vehicleregno = regno.getText(); mylivesearch.click();
	 * mylivesearch.sendKeys(vehicleregno); searchbutton.click();
	 * Thread.sleep(1000);
	 */

	// bidamount2.clear();
	// refresh.click();
	// Thread.sleep(1000);

	/*
	 * for (int i = 0; i < 10; i++) {
	 * 
	 * refresh.click(); Thread.sleep(3000); inspectedproceedtoBid1.click();
	 * Thread.sleep(1000); Quotenow1.click(); Thread.sleep(2000); try { Alert
	 * bidalert = driver.switchTo().alert(); String alertText1 = bidalert.getText();
	 * System.out.println("Alert data: " + alertText1); bidalert.accept(); } catch
	 * (Exception e) { e.printStackTrace(); } } }
	 * 
	 * private static void invalidamount() { // TODO Auto-generated method stub
	 * 
	 * } }
	 */
	// System.out.println("browser close");
	// driver.close();
}

