package com.ediig.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import com.ediig.utility.BrowserFactory;
import com.ediig.utility.Constant;
import com.ediig.utility.ExcelUtil;

public class LoginAdminEdiingPage {

	WebDriver driver;

	@FindBy(how = How.XPATH, using = ("//input[@type='text']"))
	static WebElement adminUserName;

	@FindBy(how = How.XPATH, using = ("//input[@type='password']"))
	static WebElement adminPassword;

	@FindBy(how = How.XPATH, using = ("//button[@type='button']"))
	static WebElement btnLogin;

	@FindBy(how = How.XPATH, using = ("//span[text()='buyer administration']"))
	static WebElement buyerAdministration;

	@FindBy(how = How.XPATH, using = ("//a[text()='buyer request to permission']"))
	static WebElement buyerRequestToPermission;

	@FindBy(how = How.XPATH, using = ("//tbody//tr/td[4]"))
	static WebElement firstCommunityName;

	@FindBy(how = How.XPATH, using = ("//i[@class='fa fa-check']"))
	static WebElement tickIconapproved;

	@FindBy(how = How.XPATH, using = ("//*[@id='replaceText']"))
	static WebElement requestPermission;

	@FindBy(how = How.XPATH, using = ("(//*[@class='close'])[8]"))
	static WebElement crossIcon;

	@FindBy(how = How.XPATH, using = ("//strong[text()='Approved']"))
	static WebElement approved;

	@FindBy(how = How.XPATH, using = ("(//*[text()='Inspected! Proceed to Bid'])[2]"))
	static WebElement inspectedproceedtoBid;

	public void LoginPage(WebDriver driver) {
		this.driver = driver;
		actions = new Actions(driver);
		driver.manage().window().maximize();
	}

	static String sUserName;
	static String sPassword;
	static Actions actions;

	public static void loginadminEdiig() throws Exception {
		WebDriver driver = new ChromeDriver();
		BrowserFactory.getBrowser("Chrome");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		driver.getWindowHandle();
		driver.get(Constant.URLAdmin); // here in constant page paste the correct url
		ExcelUtil.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Sheet1");
		// loginToEdiigAdmin();
		// Thread.sleep(2000);
		// }
		// public void loginToEdiigAdmin() throws Exception {
		sUserName = ExcelUtil.getCellData(10, 1);// give correct numbers
		sPassword = ExcelUtil.getCellData(10, 2);
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys(sUserName);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(sPassword);
		System.out.println("login admin");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		// btnLogin.click();
		driver.findElement(By.xpath("//span[text()='buyer administration']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//a[text()='buyer request to permission']")).click();
		Thread.sleep(1000);
		System.out.println("clicked first community name ");
		
		/*
		 * driver.findElement(By.xpath("//tbody//tr/td[4]")).click();
		 * actions.keyDown(Keys.TAB); actions.keyDown(Keys.TAB);
		 * actions.keyDown(Keys.TAB);
		 */
		 
		driver.findElement(By.xpath("//i[@class='fa fa-check']")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("Value")).sendKeys(Keys.ENTER);
		System.out.println("clicked ok");
		//actions.keyDown(Keys.ENTER);
		Thread.sleep(1000);
		driver.findElement(By.id("Value")).sendKeys(Keys.ENTER);
		System.out.println("clicked ok");
		//actions.keyDown(Keys.ENTER);
		Thread.sleep(1000);
		driver.findElement(By.xpath("  (//*[text()='Inspected! Proceed to Bid'])[2]")).click();
		
		driver.findElement(By.xpath("//strong[text()='Approved']")).click();
		Alert alertok = driver.switchTo().alert();
		String alertText = alertok.getText();
		System.out.println("Alert data: " + alertText);
		alertok.accept();
		Thread.sleep(3000);
	}
	public static void buyerAdministration() throws InterruptedException {
		buyerAdministration.click();
		Thread.sleep(1000);
		buyerRequestToPermission.click();
		Thread.sleep(1000);
		System.out.println("clicked first community name");
		firstCommunityName.click();
		Thread.sleep(1000);
		actions.keyDown(Keys.TAB);
		actions.keyDown(Keys.TAB);
		actions.keyDown(Keys.TAB);
		// tabKeyPress(3);
		tickIconapproved.click();
		inspectedproceedtoBid.click();
		actions.keyDown(Keys.ENTER);
		actions.keyDown(Keys.ENTER);
		approved.isDisplayed();
	}
}
