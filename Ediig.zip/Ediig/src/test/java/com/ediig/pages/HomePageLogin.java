package com.ediig.pages;

import com.ediig.utility.ExcelUtil;
import com.ediig.utility.Generic;

import junit.framework.Assert;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HomePageLogin {
	
	 final WebDriver driver ;
	 public HomePageLogin (WebDriver driver){
	 this.driver=driver;
	 }
	 
	 @FindBy(id="buyerLoginName")
	 static WebElement textUserName;
	//@FindBy(how = How.ID, using = "buyerLoginName")
	//static WebElement textUserName;
	
	

	@FindBy(how = How.ID, using = "buyerPassword")
	static WebElement textPassword;

	@FindBy(how = How.XPATH, using = "//button[@class='btn btn-az-primary btn-block waves-effect waves-light']")
	static WebElement btnLogin;

	@FindBy(how = How.XPATH, using = "(//a[@class='nav-link '])[1]")
	static WebElement saleCalendarTextUpOnLogin;

	@FindBy(how = How.XPATH, using = "//div[@class='login_error_msgs']")
	static WebElement LoginErrormsg;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Sale Calendar')]")
	static WebElement SaleCalendar;
	static String susername;
	static String spassword;
	
	public static void loginwithValidEdiig() throws Exception {
		//susername = ExcelUtil.getCellData(2, 1);
		//System.out.println(susername+"user name enter");
		textUserName.sendKeys(ExcelUtil.getCellData(2, 1));
		textPassword.sendKeys(ExcelUtil.getCellData(2, 2));
		btnLogin.click();
	}

	public static void verifyingLoginSuccesssfully() {
		String actualmsg = SaleCalendar.getText();
		String expectedMsg = "Sale Calendar";
		Assert.assertEquals(actualmsg, expectedMsg);
	}

	public static void loginwithinValidEdiig() throws Exception {
		
		textUserName.sendKeys(ExcelUtil.getCellData(3, 1));
		textPassword.sendKeys(ExcelUtil.getCellData(3, 2));
		btnLogin.click();
		Thread.sleep(3000);
	}

	public static void verifyInvaliddetails() throws InterruptedException {
		Thread.sleep(2000);
		String actualmsg = LoginErrormsg.getText();
		Thread.sleep(1000);
		System.out.println(actualmsg);
		String expectedMsg = "invalid user name and password";
		System.out.println(actualmsg);
		Thread.sleep(1000);
		Assert.assertEquals(actualmsg, expectedMsg);
	}

}
