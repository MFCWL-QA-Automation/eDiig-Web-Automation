
package com.ediig.pages;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MyWatchListPage {
	final static Logger log = Logger.getLogger(MyWatchListPage.class.getName());

	@FindBy(how = How.XPATH, using = ("//a[text()='My Watch List']"))
	static WebElement mywatchlisttab;

	@FindBy(how = How.XPATH, using = ("(//input[@class='select-dropdown'])[1]"))
	static WebElement mywatchchoosecategory;

	@FindBy(how = How.XPATH, using = ("//ul[@class='dropdown-content select-dropdown w-100 multiple-select-dropdown active']/li[3]"))
	static WebElement mywatchcategoty1;

	@FindBy(how = How.XPATH, using = ("//ul[@class='dropdown-content select-dropdown w-100 multiple-select-dropdown active']/li[4]"))
	static WebElement mywatchcategoty2;

	@FindBy(how = How.XPATH, using = ("//ul[@class='dropdown-content select-dropdown w-100 multiple-select-dropdown active']/li[5]"))
	static WebElement mywatchcategoty3;

	@FindBy(how = How.XPATH, using = ("//ul[@class='dropdown-content select-dropdown w-100 multiple-select-dropdown active']/li[6]"))
	static WebElement mywatchcategoty4;

	@FindBy(how = How.XPATH, using = ("(//input[@class='select-dropdown'])[2]"))
	static WebElement mywatchchooseyear;

	@FindBy(how = How.XPATH, using = ("//ul[@class=\"dropdown-content select-dropdown w-100 multiple-select-dropdown active\"]/li[3]/span"))
	static WebElement mywatchselectyear1;

	@FindBy(how = How.XPATH, using = ("//ul[@class=\"dropdown-content select-dropdown w-100 multiple-select-dropdown active\"]/li[4]/span"))
	static WebElement mywatchselectyear2;

	@FindBy(how = How.XPATH, using = ("//ul[@class=\"dropdown-content select-dropdown w-100 multiple-select-dropdown active\"]/li[5]/span"))
	static WebElement mywatchselectyear3;

	@FindBy(how = How.XPATH, using = ("//ul[@class=\"dropdown-content select-dropdown w-100 multiple-select-dropdown active\"]/li[6]/span"))
	static WebElement mywatchselectyear4;
	
	@FindBy(how = How.XPATH, using = ("//ul[@class=\"dropdown-content select-dropdown w-100 multiple-select-dropdown active\"]/li[7]"))
	static WebElement mywatchselectyear5;
	
	@FindBy(how = How.XPATH, using = ("//ul[@class=\"dropdown-content select-dropdown w-100 multiple-select-dropdown active\"]/li[8]"))
	static WebElement mywatchselectyear6;

	@FindBy(how = How.XPATH, using = ("(//input[@class='select-dropdown'])[3]"))
	static WebElement mywatchchooseinspectionreport;

	@FindBy(how = How.XPATH, using = ("//ul[@class=\"dropdown-content select-dropdown w-100 active\"]/li[3]"))
	static WebElement mywatchinspectionreportnotavailable;

	@FindBy(how = How.XPATH, using = ("(//input[@class='select-dropdown'])[4]"))
	static WebElement mywatchchooseimage;

	@FindBy(how = How.XPATH, using = (" //*[@id=\"filter\"]/div[5]/div/input"))
	static WebElement mywatchimagenotavilable;

	@FindBy(how = How.XPATH, using = ("(//input[@class='select-dropdown'])[5]"))
	static WebElement mywatchchooserc;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[1]"))
	static WebElement removefromwatchlist1;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[2]"))
	static WebElement removefromwatchlist2;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[3]"))
	static WebElement removefromwatchlist3;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[4]"))
	static WebElement removefromwatchlist4;

	@FindBy(how = How.XPATH, using = ("(//span[@class='com-text'])[1]"))
	static WebElement clicktext;

	@FindBy(how = How.XPATH, using = ("(//*[text()='Inspected! Proceed to Bid'])[1]"))
	static WebElement inspectedproceedtoBid1;

	@FindBy(how = How.XPATH, using = ("(//*[text()='Inspected! Proceed to Bid'])[2]"))
	static WebElement inspectedproceedtoBid2;
	
	@FindBy(how = How.XPATH, using = ("(//*[text()='Inspected! Proceed to Bid'])[3]"))
	static WebElement inspectedproceedtoBid3;
	
	@FindBy(how = How.XPATH, using = ("//input[@id='bidAmt0']"))
	static WebElement bidamount1;

	@FindBy(how = How.XPATH, using = ("//input[@id='bidAmt1']"))
	static WebElement bidamount2;
	
	@FindBy(how = How.XPATH, using = ("//input[@id='bidAmt2']"))
	static WebElement bidamount3;
	
	//@FindBy(xpath = ("(//button[@class=\"btn btn-primary btn-sm\"])[1]"))
	@FindBy(xpath = ("//button[@onClick='location.reload();']"))
	static WebElement closeQuote;


	@FindBy(how = How.XPATH, using = ("//a[@class='btn btn-primary btn-sm  waves-effect waves-light']/following::button[1]"))
	static WebElement Quotenow1;

	private static WebDriver driver;

	public MyWatchListPage(WebDriver driver) {
		this.driver = driver;
	}
	public static void entertomywatchlist() throws InterruptedException{
		Thread.sleep(1000);
		mywatchlisttab.click();
		Thread.sleep(2000);
	}

	public static void myWatchlistChoosefilters() throws InterruptedException {
	

		//choose category
		Thread.sleep(2000);
		MyWatchListPage.mywatchchoosecategory.click();
		Thread.sleep(2000);
		MyWatchListPage.mywatchcategoty1.click();
		Thread.sleep(1000);
		MyWatchListPage.mywatchcategoty2.click();
		Thread.sleep(1000);
		MyWatchListPage.mywatchcategoty3.click();
		Thread.sleep(1000);
		MyWatchListPage.mywatchcategoty4.click();
		Thread.sleep(1000);
		
		//Actions action = new Actions(driver);
		//action.sendKeys(Keys.ESCAPE);
		MyWatchListPage.clicktext.click();
		
		//choose year
		MyWatchListPage.mywatchchooseyear.click();
		Thread.sleep(2000);
		MyWatchListPage.mywatchselectyear1.click();
		Thread.sleep(1000);
		MyWatchListPage.mywatchselectyear2.click();
		Thread.sleep(1000);
		MyWatchListPage.mywatchselectyear3.click();
		Thread.sleep(1000);
	//	MyWatchListPage.mywatchselectyear4.click();
	//	Thread.sleep(1000);
	//	MyWatchListPage.mywatchselectyear5.click();
	//	Thread.sleep(1000);
	//	MyWatchListPage.mywatchselectyear6.click();
		Thread.sleep(1000);
		MyWatchListPage.clicktext.click();
		//action.sendKeys(Keys.ESCAPE);
		

		
		/*
		 * MyWatchListPage.mywatchchooseimage.click(); Thread.sleep(3000);
		 * MyWatchListPage.mywatchimagenotavilable.click(); Thread.sleep(2000);
		 * MyWatchListPage.clicktext.click();
		 * 
		 * MyWatchListPage.mywatchchooseinspectionreport.click(); Thread.sleep(2000);
		 * MyWatchListPage.mywatchinspectionreportnotavailable.click();
		 * Thread.sleep(1000); MyWatchListPage.clicktext.click();
		 */

		// MyWatchListPage.mywatchchooserc.click();

	}

	public static void myWatchlistdded() throws InterruptedException {
		
		List<String> regNumList = new ArrayList<String>();

		//mywatchlisttab.click();

		WebElement watchlist = driver.findElement(By.xpath("//a[text()='My Watch List']"));
		watchlist.click();
		Thread.sleep(2000);

		List<WebElement> wishListResponse = driver.findElements(By.xpath("//div[contains(@class, 'shdhover')]"));
		List<String> wishedRegNumList = new ArrayList<String>();
		for (WebElement element : wishListResponse) {
			List<WebElement> spans = element.findElements(By.tagName("li"));
			WebElement regNo = spans.stream().filter(ele -> ele.getText().contains("reg.No")).findAny().get();
			wishedRegNumList.add(regNo.getText().substring(6));
		}

		log.info("All the Reg No's in wish list " + wishedRegNumList);

		Assert.assertTrue(wishedRegNumList.containsAll(regNumList));

	}

	public static void myWatchquotenow() throws InterruptedException {
		Thread.sleep(2000);
		inspectedproceedtoBid1.click();
		Thread.sleep(2000);
		Quotenow1.click();
		Thread.sleep(2000);
		Alert alertok = driver.switchTo().alert();
		String alertText = alertok.getText();
		System.out.println("Alert data: " + alertText);
		alertok.accept();
		Thread.sleep(3000);

		inspectedproceedtoBid1.click();
		Thread.sleep(2000);
		Quotenow1.click();
		Thread.sleep(2000);
		Alert Confirmbid = driver.switchTo().alert();
		String ConfirmalertText = Confirmbid.getText();
		System.out.println("Alert data: " + ConfirmalertText);
		Thread.sleep(2000);
		Confirmbid.accept();
		Thread.sleep(3000);

	}

	public static void mywatchinvalidamount() throws InterruptedException {
		//inspectedproceedtoBid1.click();
		Thread.sleep(3000);
		
		/* inspectedproceedtoBid2.click(); 
		  Thread.sleep(2000); 
		  bidamount2.clear();
		  Thread.sleep(2000);
		  bidamount2.sendKeys("0"); 
		  Thread.sleep(3000); 
		  Quotenow1.click();
		
		
		Alert invalidamount = driver.switchTo().alert();
		String invalidamountalertText = invalidamount.getText();
		System.out.println("Alert data: " + invalidamountalertText);
		Thread.sleep(4000);
		invalidamount.accept(); */
		
		
		driver.get("https://test.ediig.com/myWatchlist");
		String parentHandle = driver.getWindowHandle();
		System.out.println("parent handle "+ parentHandle);
		 inspectedproceedtoBid2.click(); 
		  Thread.sleep(2000); 
		  bidamount2.clear();
		  Thread.sleep(2000);
		  bidamount2.sendKeys("221123831"); 
		  System.out.println("enetered more than max ");
		  Thread.sleep(3000); 
		  Quotenow1.click();
		  
		  Set<String>hanles = driver.getWindowHandles();
		  for(String handle:hanles) {
			  System.out.println(handle);
			  if(!handle.equals(parentHandle)) {
				  driver.switchTo().window(handle);
				  closeQuote.click();
			  }
			  }
		  }
		  
		
		
		//Alert zeroamount = driver.switchTo().alert();
		//Thread.sleep(4000);
		//zeroamount.accept();
		//String invalidQuote = driver.switchTo().toString();
		//driver.switchTo().window(invalidQuote);
		
		
		
	
	public static void removefromwatchlist() throws InterruptedException {
		Thread.sleep(2000);
		//MyWatchListPage.removefromwatchlist1.click();
		MyWatchListPage.removefromwatchlist2.click();
		//MyWatchListPage.removefromwatchlist3.click();
		
	}
}
