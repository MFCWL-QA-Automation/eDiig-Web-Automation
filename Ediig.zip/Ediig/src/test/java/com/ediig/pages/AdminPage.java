package com.ediig.pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.ediig.utility.Solvent;



public class AdminPage extends Solvent {
	
	@FindBy(xpath = ("//input[@type='text']"))
	public WebElement adminUserName;

	@FindBy(xpath = ("//input[@type='password']"))
	public WebElement adminPassword;

	@FindBy(xpath = ("//button[@type='button']"))
	public WebElement btnLogin;
	
	@FindBy(xpath = ("//span[text()='buyer administration']"))
	static WebElement buyerAdministaration;
	
	@FindBy(xpath = ("//a[text()='buyer request to permission']"))
	static WebElement buyerRequestToPermission;

	@FindBy(xpath = ("//tbody//tr/td[4]"))
	static WebElement firstCommunityName;

	@FindBy(xpath = ("(//i[@class='fa fa-check'])[1]"))
	static WebElement tickIconapproved;

	@FindBy(xpath = ("//*[@id='replaceText']"))
	static WebElement requestPermission;

	@FindBy(xpath = ("(//*[@class='close'])[8]"))
	static WebElement crossIcon;

	@FindBy(xpath = ("//strong[text()='Approved']"))
	static WebElement approved;

	static Actions actions;
	public AdminPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	public void navigateToAdmin(){
		driver.navigate().to("http://staging.admin.ediig.com");
	}
	
	public static void tabKeyPress(int N) {
		for (int i = N; i <= N; i++) {
			actions.keyDown(Keys.TAB);
		}
	}
	
	public void loginToAdmin() throws InterruptedException{
		adminUserName.sendKeys("admin");
		adminPassword.sendKeys("admin");
		btnLogin.click();
		buyerAdministaration.click();
		Thread.sleep(1000);
		buyerRequestToPermission.click();
		Thread.sleep(1000);
		
		
		//WebElement approveelement = driver.findElement(By.xpath("(//tr[@role='row']/td[1])[10]"));
		//	JavascriptExecutor js = (JavascriptExecutor)driver;
		//	js.executeScript("arguments[0].scrollIntoView()", approveelement);
		//approveelement.click();
		
		
		//JavascriptExecutor js = (JavascriptExecutor) driver;

        //Launch the application		
       // driver.get("http://demo.guru99.com/test/guru99home/");

        //Find element by link text and store in variable "Element"        		
        //WebElement Element = driver.findElement(By.xpath("//i[@class='fa fa-check']"));

        //This will scroll the page till the element is found		
       // js.executeScript("arguments[0].scrollIntoView();", tickIconapproved);
		
		//firstCommunityName.sendKeys(Keys.TAB);
		
		//firstCommunityName.click();
		//Thread.sleep(1000);
		//tabKeyPress(3);
		Actions action = new Actions(driver);
		action.moveToElement(tickIconapproved);
		System.out.println("before clikked");
		tickIconapproved.click();
		Thread.sleep(2000);
		System.out.println(" clikked");
		
		Alert Confirmbid = driver.switchTo().alert();
		String ConfirmalertText = Confirmbid.getText();
		System.out.println("Alert data: " + ConfirmalertText);
		Thread.sleep(2000);
		Confirmbid.accept();
		
		Alert finalapprove = driver.switchTo().alert();
		String approve = finalapprove.getText();
		System.out.println("Alert data: " + ConfirmalertText);
		Thread.sleep(2000);
		Confirmbid.accept();
		
		driver.navigate().back();
	
	}
	
	public void approveEvent(){
		
	}

}
