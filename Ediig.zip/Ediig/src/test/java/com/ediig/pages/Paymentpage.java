package com.ediig.pages;

import java.awt.List;
import java.util.ArrayList;
import java.util.logging.Logger;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import junit.framework.Assert;

public class Paymentpage {
	private static final Logger log = Logger.getLogger(MyLiveEventsPage.class.getName());
	
	@FindBy(how = How.XPATH, using = ("//a[text()='Payments']"))
	static WebElement paymenttab;
	
	@FindBy(how = How.XPATH, using = ("(//i[@class=\"fas fa-rupee-sign\"])[2]"))
	static WebElement selectplanyear1;
	
	@FindBy(how = How.XPATH, using = ("(//i[@class=\"fas fa-rupee-sign\"])[3]"))
	static WebElement selectplanyear2;
	
	@FindBy(how = How.XPATH, using = ("(//i[@class=\"fas fa-rupee-sign\"])[4]"))
	static WebElement selectplanyear3;
	
	@FindBy(how = How.XPATH, using = ("//button[@onclick='payOnline(1)']"))
	static WebElement payonlineRenew;
	
	@FindBy(how = How.XPATH, using = ("//button[@onclick='payOnline(2)']"))
	static WebElement payonlinetopupEMD;
	
	@FindBy(how = How.XPATH, using = ("//button[@onclick='payOnline(3)']"))
	static WebElement payonlinebuyerfee;
	
	@FindBy(how = How.XPATH, using = ("//button[text()='Make Payment']"))
	static WebElement makevehiclepayment;
	
	@FindBy(how = How.XPATH, using = ("(//i[@class='fas fa-angle-down rotate-icon'])[1]"))
	static WebElement renewbuyeridopen;
	
	@FindBy(how = How.XPATH, using = ("(//i[@class='fas fa-angle-down rotate-icon'])[2]"))
	static WebElement topupEMDopen;
	
	@FindBy(how = How.XPATH, using = ("(//i[@class='fas fa-angle-down rotate-icon'])[3]"))
	static WebElement paybuyerfeeopen;
	
	@FindBy(how = How.XPATH, using = ("(//i[@class='fas fa-angle-down rotate-icon'])[4]"))
	static WebElement makevehiclepaymentopen;
	
	@FindBy(how = How.XPATH, using = ("//input[@id='ccard_number']"))
	static WebElement cardno;
	
	@FindBy(how = How.XPATH, using = ("//input[@id='cname_on_card']"))
	static WebElement nameoncard;
	
	@FindBy(how = How.XPATH, using = ("//input[@id='ccvv_number']"))
	static WebElement cardcvvno;
	
	@FindBy(how = How.XPATH, using = ("//select[@id=\"cexpiry_date_month\"]/option[1]"))
	static WebElement choosecardexpdatemonth;
	
	@FindBy(how = How.XPATH, using = ("//select[@id=\"cexpiry_date_month\"]/option[6]"))
	static WebElement selectcardexpdatemonth;
	
	
	@FindBy(how = How.XPATH, using = ("//select[@id='cexpiry_date_year']"))
	static WebElement choosecardexpdateyear;
	
	@FindBy(how = How.XPATH, using = ("//select[@id=\"cexpiry_date_year\"]/option[2]"))
	static WebElement selectxpdateyear;
	
	//select[@id="cexpiry_date_year"]/option[2]
	
	@FindBy(how = How.XPATH, using = ("(//input[@id='pay_button'])[1]"))
	static WebElement paynowrenewbuyerid;
	
	@FindBy(how = How.XPATH, using = ("(//input[@id='pay_button'])[1]"))
	static WebElement paynowEMD;
	
	
	@FindBy(how = How.XPATH, using = ("//input[@id='password']"))
	static WebElement enterotp;
	
	@FindBy(how = How.XPATH, using = ("//input[@id='submitBtn']"))
	static WebElement paybuttonafterotp;
	
	@FindBy(how = How.XPATH, using = ("(//button[@class='btn btn-az-primary  waves-effect waves-light'])[1]"))
	static WebElement printreceipt;
	
	@FindBy(how = How.XPATH, using = ("(//button[@class='btn btn-az-primary  waves-effect waves-light'])[2]"))
	static WebElement backafterpayment;
	
	@FindBy(how = How.XPATH, using = ("//input[@id='emdAmount']"))
	static WebElement enterEMDamount;
	
	@FindBy(how = How.XPATH, using = ("//select[@id=\"auctionstates\"]"))
	static WebElement choosestatepaybuyerfee;
	
	@FindBy(how = How.XPATH, using = ("//select[@id=\"auctionstates\"]/option[1]"))
	static WebElement selectstatepaybuyerfee;
	
	@FindBy(how = How.XPATH, using = ("//select[@id='auctionCity']"))
	static WebElement chooseauctionCitybuyerfee;
	
	@FindBy(how = How.XPATH, using = ("//select[@id='auctionCity']/option[2]"))
	static WebElement selectauctionCitybuyerfee;
	
	@FindBy(how = How.XPATH, using = ("//select[@id='auctionCommunities']"))
	static WebElement chooseauctionCommunities;
	
	@FindBy(how = How.XPATH, using = ("//select[@id='auctionCommunities']/option[3]"))
	static WebElement selectauctionCommunities;
	
	@FindBy(how = How.XPATH, using = ("//input[@id='noOfVehicles']"))
	static WebElement noOfVehiclespaybuyerfee ;
	
	@FindBy(how = How.XPATH, using = ("//input[@id='contractNo']"))
	static WebElement contractNopaybuyerfee ;
	
	@FindBy(how = How.XPATH, using = ("//input[@id='buyerFeeAmount']"))
	static WebElement buyerFeeAmount ;
	
	@FindBy(how = How.XPATH, using = ("//input[@class='select-dropdown active']"))
	static WebElement clintnamevehiclepayment ;
	
	@FindBy(how = How.XPATH, using = ("(//span[@class='filtrable'])[2]"))
	static WebElement selectclintname ;
	
	@FindBy(how = How.XPATH, using = ("(//label[@class='custom-control-label'])[1]"))
	static WebElement selectvehicle ;
	
	@FindBy(how = How.XPATH, using = ("//button[@id='primary-button']"))
	static WebElement gobackvehivlepayment ;
	
	String creditcardno = "5123456789012346";
	
	@FindBy(how = How.XPATH, using = ("(//a[@class=\"nav-link \"])[1]"))
	static WebElement home ;
	
	
	
	//button[@id="primary-button"]
	

	
	
	private static WebDriver driver;

	public Paymentpage(WebDriver driver) {
		this.driver = driver;
	}

	public static void enterintopayment() throws InterruptedException {
	Thread.sleep(2000);	
	Paymentpage.paymenttab.click();
	Thread.sleep(2000);	
	}
	
	public static void renewbuyerid() throws InterruptedException {
		
		Paymentpage.payonlineRenew.click();
		Thread.sleep(2000);
		
		Alert paymentdetails = driver.switchTo().alert();
		String ConfirmalertText = paymentdetails.getText();
		System.out.println("Alert data: " + ConfirmalertText);
		Thread.sleep(2000);
		paymentdetails.accept();
		Thread.sleep(1000);
		
		Paymentpage.selectplanyear1.click();
		Thread.sleep(1000);
		Paymentpage.payonlineRenew.click();
		Thread.sleep(1000);
		Paymentpage.cardno.clear();
		Thread.sleep(5000);
		//String creditcardno = "5123456789012346";
		//Paymentpage.cardno.sendKeys(creditcardno);
		//Paymentpage.cardno.sendKeys(creditcardno);
		Paymentpage.cardno.clear();
		Thread.sleep(2000);
		Paymentpage.cardno.sendKeys("123456789012346");
		Thread.sleep(2000);
		Paymentpage.nameoncard.click();
		Thread.sleep(2000);
		log.info("invalid card no");
		Thread.sleep(5000);
		Paymentpage.cardno.clear();
		
	
		String[] cardNos = {"512", "3", "4", "5","6", "7", "8","9", "0", "1","2", "3", "4","6"};
		for (String cardNo:cardNos) {
			Thread.sleep(2000);
			Paymentpage.cardno.sendKeys(cardNo);
		}
		
		/*for(int i = 0; i<creditcardno.length(); i++) {
		      // access each character
		char a = creditcardno.charAt(i);
		Thread.sleep(1000);
		Paymentpage.cardno.sendKeys(a);
		}
		*/
		Paymentpage.nameoncard.sendKeys("testqa");
		Thread.sleep(1000);
		Paymentpage.cardcvvno.sendKeys("123");
		Thread.sleep(1000);
		Paymentpage.choosecardexpdatemonth.click();
		Thread.sleep(1000);
		Paymentpage.selectcardexpdatemonth.click();
		Thread.sleep(1000);
		Paymentpage.choosecardexpdateyear.click();
		Thread.sleep(1000);
		Paymentpage.selectxpdateyear.click();
		Thread.sleep(1000);
		Paymentpage.paynowrenewbuyerid.click();
		Thread.sleep(5000);
		Paymentpage.enterotp.sendKeys("123456");
		Thread.sleep(4000);
		
		Paymentpage.paybuttonafterotp.click();
		Thread.sleep(4000);
		
		
		/*Paymentpage.backafterpayment.click();
		Thread.sleep(2000);
		System.out.println("payment sucessfull");
		Thread.sleep(7000);
		
		String actualmsg = home.getText();
		Thread.sleep(4000);
		String expectedMsg = " Home";
		Thread.sleep(2000);
		Assert.assertEquals(actualmsg, expectedMsg);
		System.out.println("home page");*/
	}
		//Paymentpage.backafterpayment.click();
		
		
		/*try {
			Alert save = driver.switchTo().alert();
			Thread.sleep(2000);
			save.accept();
		} 	
		catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			Alert savetolocal = driver.switchTo().alert();
			Thread.sleep(2000);
			savetolocal.accept();
		} 
		catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}*/
	
	
		public static void topupEMD() throws InterruptedException {
			//driver.findElement(By.xpath("//a[@class=\"font-weight-bold white-text\"]"));
			
			Thread.sleep(2000);
			Paymentpage.topupEMDopen.click();
			Thread.sleep(2000);
			Paymentpage.enterEMDamount.sendKeys("15000");
			Thread.sleep(2000);
			Paymentpage.payonlinetopupEMD.click();
			Thread.sleep(2000);
			Paymentpage.cardno.clear();
			Thread.sleep(2000);
			Paymentpage.cardno.sendKeys("123456789012346");
			Thread.sleep(2000);
			Paymentpage.nameoncard.click();
			Thread.sleep(2000);
			log.info("invalid card no");
			Thread.sleep(5000);
			Paymentpage.cardno.clear();
			
			String[] cardNos = {"512", "3", "4", "5","6", "7", "8","9", "0", "1","2", "3", "4","6"};
			for (String cardNo:cardNos) {
				Thread.sleep(2000);
				Paymentpage.cardno.sendKeys(cardNo);
			}
			Paymentpage.nameoncard.sendKeys("testqa");
			Thread.sleep(2000);
			Paymentpage.cardcvvno.sendKeys("123");
			Thread.sleep(2000);
			Paymentpage.choosecardexpdatemonth.click();
			Thread.sleep(2000);
			Paymentpage.selectcardexpdatemonth.click();
			Thread.sleep(2000);
			Paymentpage.choosecardexpdateyear.click();
			Thread.sleep(2000);
			Paymentpage.selectxpdateyear.click();
			Thread.sleep(2000);
			Paymentpage.paynowEMD.click();
			Thread.sleep(2000);
			Paymentpage.enterotp.sendKeys("123456");
			Thread.sleep(2000);
			Paymentpage.paybuttonafterotp.click();
			Thread.sleep(4000);
			log.info(" EMD payment sucessfull");
			System.out.println("EMD payment sucessfull");
			Paymentpage.backafterpayment.click();
			driver.navigate().back();
			
			
			//driver.execute_script("window.history.go(-1)")
			//Paymentpage.backafterpayment.click();
			//driver.navigate().forward();
			Thread.sleep(2000);
			Paymentpage.paymenttab.click();
			
	}
		public static void paybuyerfee() {
			Paymentpage.paybuyerfeeopen.click();
			Paymentpage.choosestatepaybuyerfee.click();
			Paymentpage.selectstatepaybuyerfee.click();
			Paymentpage.chooseauctionCitybuyerfee.click();
			Paymentpage.selectauctionCitybuyerfee.click();
			Paymentpage.chooseauctionCommunities.click();
			Paymentpage.selectauctionCommunities.click();
			Paymentpage.noOfVehiclespaybuyerfee.sendKeys("5");
			Paymentpage.contractNopaybuyerfee.sendKeys("9880123321");
			Paymentpage.buyerFeeAmount.sendKeys("25000");
			Paymentpage.payonlinebuyerfee.click();
		}
		public static void makevehiclepayment() throws InterruptedException {
			Paymentpage.makevehiclepaymentopen.click();
			Paymentpage.clintnamevehiclepayment.click();
			Paymentpage.selectclintname.click();
			Paymentpage.selectvehicle.click();
			Paymentpage.makevehiclepayment.click();
			Alert makepayment = driver.switchTo().alert();
			Thread.sleep(2000);
			makepayment.accept();
			Paymentpage.gobackvehivlepayment.click();
		}
}