package com.ediig.pages;

import static org.testng.Assert.assertTrue;

import java.util.logging.Logger;

import javax.xml.xpath.XPath;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import junit.framework.Assert;

public class ContactusPage {

	private static final Logger log = Logger.getLogger(ContactusPage.class.getName());
	
	@FindBy(xpath="//a[contains(text(),'Contact Us')]")
	static WebElement contactustab;
	
	@FindBy(xpath = "//a[text()='Customer Care Number location']")
	static WebElement CustomerCareNumber;
	
	
	
	private static WebDriver driver;

	public ContactusPage(WebDriver driver) {
		ContactusPage.driver = driver;
	}
	
	public static  void contactus() throws InterruptedException {
		Thread.sleep(2000);
		contactustab.click();
		Thread.sleep(2000);
		
	}
	public static void validatecontactus() throws InterruptedException {
		String actualmsg =  CustomerCareNumber.getText();
		
		String expectedMsg = "Customer Care Number location";
		Assert.assertEquals(actualmsg, expectedMsg);
		System.out.println("contactus validated");
		Thread.sleep(1000);
		contactustab.click();
		
		
		
		
	}
		
		
	}
	
	

