package com.ediig.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import com.ediig.utility.Constant;
import com.ediig.utility.ExcelUtil;
import com.ediig.utility.Solvent;
import com.ediig.utility.BrowserFactory;
import com.ediig.utility.Constant;

import junit.framework.Assert;

public class AllLiveEventsPage extends Solvent {
	final static Logger log = Logger.getLogger(AllLiveEventsPage.class.getName());

	

	@FindBy(how = How.XPATH, using = ("//a[text()='All Live Events']"))
	static WebElement allLiveEventsTab; // UI element

	@FindBy(xpath = "//badge[text()=' Awaiting Permission']")
	public static WebElement awaiting;

	// choose Location
	@FindBy(how = How.XPATH, using = ("//label[text()='Location']/../div/input"))
	static WebElement alllivechooseLocationDropdown;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Location')]/following::li[4]"))
	static WebElement location1;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Location')]/following::li[5]"))
	static WebElement location2;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Location')]/following::li[6]"))
	static WebElement location3;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Location')]/following::li[7]"))
	static WebElement location4;
	
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Location')]/following::li[3]"))
	static WebElement location5;


	@FindBy(how = How.XPATH, using = ("	(//label[text()='Select all'])[2]"))
	static WebElement locationselectall;

	// choose seller name
	@FindBy(how = How.XPATH, using = ("//label[text()='Seller Name']/../div/input"))
	static WebElement alllivechooseSellerName;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller Name')]/following::li[3]"))
	static WebElement selectsellername1;

	@FindBy(how = How.XPATH, using = ("//button[@id=\"submit\"]"))
	static WebElement eventStatusXpath;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller Name')]/following::li[5]"))
	static WebElement selectsellername2;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller Name')]/following::li[6]"))
	static WebElement selectsellername3;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller Name')]/following::li[7]"))
	static WebElement selectsellername4;
	
	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Seller Name')]/following::li[9]"))
	static WebElement selectsellername5;


	@FindBy(how = How.XPATH, using = ("	(//label[text()='Select all'])[1]"))
	static WebElement selectall;

	// choose event type
//	@FindBy(how = How.XPATH, using = ("//label[text()='Event Type']/../div/input"))
//	static WebElement alllivechooseEventType;
//	
	//@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Event Type')]/following::li[1]"))
	@FindBy(how = How.XPATH, using = ("(//input[@class='select-dropdown'])[3]"))
	static WebElement alllivechooseEventType;

	@FindBy(how = How.XPATH, using = ("//label[contains(text(),'Event Type')]/following::li[3]"))
	static WebElement narmaleventtype1;

	// open live event
	// @FindBy(how = How.XPATH, using = ("(//tr[@role='row']/td[1])[10]"))
	@FindBy(how = How.XPATH, using = ("(//table[@id='liveEventTabel']/tbody//a[not(contains(text(), 'eT-'))][1])[2]"))
	WebElement openliveEvent;

	@FindBy(how = How.XPATH, using = ("(//*[text()='Inspected! Proceed to Bid'])[2]"))
	WebElement inspectedproceedtoBid;

	// @FindBy(how= How.XPATH,using =( "//*[@id=\"submit\"]"))
	@FindBy(how = How.XPATH, using = ("//a[@class='btn btn-primary btn-sm  waves-effect waves-light']/following::button[1]"))
	static WebElement Quotenow;

	@FindBy(how = How.XPATH, using = ("(//*[text()='Inspected! Proceed to Bid'])[2]"))
	static WebElement closebid;

	// choose category
	@FindBy(how = How.XPATH, using = ("//label[text()='Category']/../div/input"))
	static WebElement chooseCategoroyDropdown;

	@FindBy(how = How.XPATH, using = ("//input[@id='search']"))
	static WebElement searchwithvehicleno;

	@FindBy(how = How.XPATH, using = ("//*[@id=\"MaterialButton-addon4\"]/button[1]"))
	static WebElement clicksearch;

	@FindBy(how = How.XPATH, using = ("(//div[@class='dataTables_info'])[1]"))
	static WebElement clicksidetest;

	@FindBy(how = How.XPATH, using = ("//tr[@role='row']/td[1]"))
	static WebElement allLiveEventsFirstColumn;

	@FindBy(how = How.XPATH, using = ("//*[@id='replaceText']"))
	static WebElement requestPermission;

	@FindBy(how = How.XPATH, using = ("//*[@id='globalBidForm']/div[1]/div/div[3]/div/a"))
	static WebElement refresh;
//	

	@FindBy(how = How.XPATH, using = ("//*[@id=\"perMsg\"]/div/div/div[1]/button/span"))
	static WebElement crossiconclose;

//	(//button[@class='close'])[6]

	@FindBy(how = How.XPATH, using = ("//a[@class='btn btn-primary btn-sm  waves-effect waves-light']/following::button[1]"))
	static WebElement Quotenow1;

	@FindBy(how = How.XPATH, using = "//input[@type='text']")
	static WebElement adminUserName;

	@FindBy(how = How.XPATH, using = "//input[@type='password']")
	static WebElement adminPassword;

	@FindBy(how = How.XPATH, using = "//button[@type='button']")
	static WebElement btnLogin;

	@FindBy(how = How.XPATH, using = "//span[text()='buyer administration']")
	static WebElement buyerAdministration;

	@FindBy(how = How.XPATH, using = "//a[text()='buyer request to permission']")
	static WebElement buyerRequestToPermission;

	@FindBy(how = How.XPATH, using = "//tbody//tr/td[4]")
	static WebElement firstCommunityName;

	@FindBy(how = How.XPATH, using = ("//i[@class='fa fa-check']"))
	static WebElement tickIconapproved;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[3]"))
	static WebElement addtowatchlist1;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[4]"))
	static WebElement addtowatchlist2;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[5]"))
	static WebElement addtowatchlist3;

	@FindBy(how = How.XPATH, using = ("(//button[@class='badge badge-primary'])[6]"))
	static WebElement addtowatchlist4;

	@FindBy(how = How.XPATH, using = ("//strong[text()='Approved']"))
	static WebElement approved;

	@FindBy(how = How.XPATH, using = ("	(//tr[@role='row']/td[1])[1]"))
	static WebElement liveevent1;

	@FindBy(how = How.XPATH, using = ("	(//tr[@role='row']/td[1])[2]"))
	static WebElement liveevent2;

	@FindBy(how = How.XPATH, using = ("	(//tr[@role='row']/td[1])[3]"))
	static WebElement liveevent3;

	@FindBy(how = How.XPATH, using = ("	(//tr[@role='row']/td[1])[4]"))
	static WebElement liveevent4;

	@FindBy(how = How.XPATH, using = ("	(//tr[@role='row']/td[1])[5]"))
	static WebElement liveevent5;

	@FindBy(how = How.XPATH, using = ("	(//tr[@role='row']/td[1])[6]"))
	static WebElement liveevent6;

	@FindBy(how = How.XPATH, using = ("	(//tr[@role='row']/td[1])[7]"))
	static WebElement liveevent7;

	@FindBy(how = How.XPATH, using = ("	(//tr[@role='row']/td[1])[8]"))
	static WebElement liveevent8;

	@FindBy(how = How.XPATH, using = ("	(//tr[@role='row']/td[1])[9]"))
	static WebElement liveevent9;

	@FindBy(how = How.XPATH, using = ("	(//tr[@role='row']/td[1])[10]"))
	static WebElement liveevent10;

	@FindBy(how = How.XPATH, using = ("(//div[@class='dataTables_info'])[1]"))
	static WebElement dataInfo;

	@FindBy(how = How.XPATH, using = ("//div[@id='liveEventTabel_info']"))
	static WebElement showingentries;

	// div[@id='liveEventTabel_info']
	// ---------------------------------------------------------------------------------------------------------------

	@FindBy(xpath = "//ul[@class='dropdown-content select-dropdown w-100 multiple-select-dropdown active']//span[@class='filtrable']")
	public List<WebElement> sellerList;

	@FindBy(xpath = "//ul[@class='dropdown-content select-dropdown w-100 multiple-select-dropdown active']//span[@class='filtrable']")
	public List<WebElement> locationList;

	@FindBy(xpath = "(//div[@class='dataTables_info'])[1]")
	public WebElement clickwhitespace;

	@FindBy(xpath = "(//div[@class='col-sm-12'])[1]//a")
	public List<WebElement> liveEventsGrid;

	@FindBy(xpath = "//ul[@class='dropdown-content select-dropdown w-100 active']//li[3]//span")
	public WebElement normalEventType;

	// @FindBy(xpath = "//button[@class='btn btn-danger btn-sm waves-effect
	// waves-light']")

	// @FindBy(xpath = "//button[contains(text(),'REQUEST PERMISSION')]")
	@FindBy(xpath = "//button[contains(text(),'Request Permission')]")
//	@FindBy(xpath = "//a[@class='btn btn-primary btn-sm  waves-effect waves-light']/following::button[1]")
	public WebElement requestPermissionStatus;
	// *[@id='replaceText']

	@FindBy(xpath = "//badge[text()=' Awaiting Permission']")
	static WebElement awaitingStatus;

	@FindBy(xpath = "//*[@id='replaceText']/button")
	public WebElement Requestpermissinnew;

	// *[@id="replaceText"]/button

	@FindBy(xpath = ("//a[@class='btn btn-primary btn-sm  waves-effect waves-light']/following::button[1]"))
	public WebElement quoteNowStatus;
	
	@FindBy(xpath = ("(//button[@class=\"btn btn-primary btn-sm\"])[1]"))
	public WebElement closeQuote;

	public AllLiveEventsPage(WebDriver driver) {
		System.out.println("all live page constructor");
		this.driver = driver;
		actions = new Actions(driver);
	}

	static String sUserName;
	static String sPassword;
	Actions actions;

	public static void clickOnAlllivevents() throws InterruptedException {
		Thread.sleep(2000);
		allLiveEventsTab.click();
		Thread.sleep(2000);
		System.out.println("enter to all live");
		
		Reporter.log("click on alllive events");
	}

	public static void alllivechooseLocation() throws InterruptedException {
		alllivechooseLocationDropdown.click();
		Thread.sleep(2000);
		location1.click();
		Thread.sleep(1000);
		location2.click();
		Thread.sleep(1000);
		location3.click();
		Thread.sleep(1000);
		location4.click();
		Thread.sleep(1000);
		location5.click();
		Thread.sleep(2000);
		clicksidetest.click();

	}

	public void alllivechooseSellerName() throws InterruptedException {
		alllivechooseSellerName.click();
		Thread.sleep(2000);
		selectsellername1.click();
		Thread.sleep(1000);
		selectsellername2.click();
		Thread.sleep(1000);
		selectsellername3.click();
		Thread.sleep(1000);
		selectsellername4.click();
		Thread.sleep(2000);
		selectsellername5.click();
		clicksidetest.click();
		Thread.sleep(2000);

	}

	public void alllivechooseEventType() throws InterruptedException {
		Thread.sleep(5000);
		alllivechooseEventType.click();
		Thread.sleep(2000);
		narmaleventtype1.click();
		Thread.sleep(2000);
		clicksidetest.click();
		Thread.sleep(1000);

	}

	public void showingentriesno() throws InterruptedException {
		log.info(AllLiveEventsPage.showingentries.getText());
	}

	/*
	 * String linkText = openliveEvent.getText(); String cityText =
	 * openliveEvent.getText(); String sellerText = openliveEvent.getText(); String
	 * concatedText = "->"+cityText+"->"+sellerText;
	 * 
	 * if(linkText.contains(concatedText)) { // make assert pass }else { //fail }
	 */
	public void openliveevent() throws InterruptedException {
		Thread.sleep(2000);
		openliveEvent.click();
		System.out.println("event opened");
		Thread.sleep(1000);
		// refresh.click();
		// System.out.println("clicked refresh");
		// Requestpermissinnew.click();
		// System.out.println("clicked Requestpermission");

	}

	public void addToWatchlist() {
		addtowatchlist1.click();
		addtowatchlist2.click();
		addtowatchlist3.click();
		addtowatchlist4.click();
	}

	public void eventStatus() throws InterruptedException {
		// if(eventStatus.contains("REQUEST PERMISSION")){
		// if(Requestpermissinnew.isDisplayed()) {
		
		Thread.sleep(2000);

		if (!driver.findElements(By.xpath("//*[@id='replaceText']/button")).isEmpty()) {

			System.out.println("if else loop reached request ");
			Requestpermissinnew.click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[@class=\"c2_btn-yes\"]")).click();
			//Alert agree = driver.switchTo().alert();
			Thread.sleep(1000);
			//agree.accept();
			System.out.println("clikked ");
			
			Thread.sleep(3000);
			driver.switchTo().activeElement();
			Thread.sleep(7000);
			crossiconclose.click();
			Thread.sleep(3000);

			System.out.println("not request permission");

			// requestPermissionStatus.click();
			Thread.sleep(3000);
			openNewWindowTab();
			switchToNewlyWIndow("Untitled");
			AdminPage admin = new AdminPage(driver);
			admin.navigateToAdmin();
			admin.loginToAdmin();

			admin.approveEvent();
			switchToNewlyWIndow("eDiig - India's leading Automobile Exchange Platform");
			reloadPage();

			/// if(eventStatus.contains("QUOTE NOW")){
			// boolean localTest=true;
			// return localTest;
		}

		// else if(awaitingStatus.isDisplayed()){
		else if (!driver.findElements(By.xpath("//badge[text()=' Awaiting Permission']")).isEmpty()) {
			openNewWindowTab();
			switchToNewlyWIndow("Untitled");
			AdminPage admin = new AdminPage(driver);
			admin.navigateToAdmin();
			admin.loginToAdmin();
			admin.approveEvent();
			switchToNewlyWIndow("eDiig - India's leading Automobile Exchange Platform");
			reloadPage();
			// if(eventStatus.contains("QUOTE NOW")){
			// boolean localTest=true;
			// return localTest;
		} else {
			Quotenow1.click();
			Thread.sleep(1000);
			acceptAlert();
			inspectedproceedtoBid.click();
			Thread.sleep(1000);
			Quotenow1.click();
			Alert Confirmbid = driver.switchTo().alert();
			String ConfirmalertText = Confirmbid.getText();
			System.out.println("Alert data: " + ConfirmalertText);
			Thread.sleep(2000);
			Confirmbid.accept();
			Thread.sleep(3000);
			Alert successbid = driver.switchTo().alert();
			Thread.sleep(2000);
			successbid.accept();
			
		}
		
	}
	
	public void clickQuotes() throws InterruptedException {
		boolean continueQuoting = true;
		
		while(continueQuoting) {
			
			inspectedproceedtoBid.click();
			Thread.sleep(2000);
			Quotenow1.click();
			Thread.sleep(2000);
			Alert Confirmbid = driver.switchTo().alert();
			String ConfirmalertText = Confirmbid.getText();
			System.out.println("Alert data: " + ConfirmalertText);
			Thread.sleep(2000);
			Confirmbid.accept();
			Thread.sleep(3000);

			Alert successbid = driver.switchTo().alert();
			String successbidalertText = successbid.getText();
			System.out.println("Alert data: " + successbidalertText);
			Thread.sleep(3000);
			successbid.accept();
			System.out.println("bid submited sucsessfully");
			Thread.sleep(3000);
			}
			
			
			// if thresdhold reached, 
		//set continueQuoting = false
		}
		
	}

// boolean localTest=false;

/*
 * String biddedTimesText = normalEventType.getText(); int biddedTimes =
 * Integer.parseInt(biddedTimesText);
 * 
 * while(biddedTimes<10){ // do operations biddedTimesText =
 * normalEventType.getText(); biddedTimes = Integer.parseInt(biddedTimesText);
 * try{ Alert a = new Alert(); String a.text(); if(a.){ break; }
 * }catch(Exception e) { e.printStackTrace(); } }
 */

// return localTest;
// driver.navigate().back();

////////////////////////////////////////////////////////////////////////////////////
/*
 * public void loginStagingEdiig() throws Exception { WebDriver driver1 = new
 * ChromeDriver(); BrowserFactory.getBrowser("Chrome");
 * driver1.manage().window().maximize();
 * driver1.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
 * driver1.getWindowHandle(); driver1.get(Constant.URLAdmin); //here in constant
 * page paste the correct url ExcelUtil.setExcelFile(Constant.Path_TestData +
 * Constant.File_TestData, "Sheet1"); loginToEdiigAdmin();
 * //driver1.switchTo().defaultContent(); driver1.quit(); Thread.sleep(2000); }
 * public void loginToEdiigAdmin() throws Exception { //sUserName =
 * ExcelUtil.getCellData(10, 1);//give correct numbers //sPassword =
 * ExcelUtil.getCellData(10, 2);
 * driver.findElement(By.xpath("//input[@type='text']")).sendKeys("admin");
 * driver.findElement(By.xpath("//input[@type='text']")).sendKeys("admin");
 * btnLogin.click(); }
 * /////////////////////////////////////////////////////////////////////////////
 * ///////////////// public void tabKeyPress(int N) { for(int i=N;i<=N;i++) {
 * actions.keyDown(Keys.TAB); }}
 * 
 * 
 * public void requestPermissionClickAndProceed() throws Exception {
 * requestPermission.click(); Thread.sleep(1000);; crossIcon.click();
 * Thread.sleep(1000); loginStagingEdiig();
 * 
 * buyerAdministration.click(); Thread.sleep(1000);
 * buyerRequestToPermission.click(); Thread.sleep(1000);
 * firstCommunityName.click(); Thread.sleep(1000); tabKeyPress(3);
 * tickIconapproved.click();
 * 
 * DesiredCapabilities dc = new DesiredCapabilities();
 * dc.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
 * UnexpectedAlertBehaviour.IGNORE); //d = new FirefoxDriver(dc); try { Object
 * myButton; //click(myButton); } catch (UnhandledAlertException f) { try {
 * Alert alert = driver.switchTo().alert(); String alertText = alert.getText();
 * System.out.println("Alert data: " + alertText); alert.accept(); } catch
 * (NoAlertPresentException e) { e.printStackTrace(); }
 * 
 * } }}
 * 
 * Alert clickok = driver.switchTo().clickok(); driver.switchTo( ).alert(
 * ).accept(); inspectedproceedtoBid.click(); actions.keyDown(Keys.ENTER);
 * actions.keyDown(Keys.ENTER); approved.isDisplayed();
 * 
 * } }
 * 
 */
