package com.ediig.testcases.listener;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import org.automationtesting.excelreport.Xl;
import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.xml.XmlSuite;

public class TestCasesReportGenerator implements IReporter {

	private static final String DATE_FORMAT = "yyyy-MM-dd_hh-mm-ss";

	public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {

		try {
			String data = new SimpleDateFormat(DATE_FORMAT).format(new Date());
			Xl.generateReport("E:\\Reports", data + "_MyProject.xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
