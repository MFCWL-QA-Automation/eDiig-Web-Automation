package com.ediig.testcases;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ediig.pages.MyLiveEventsPage;
import com.ediig.pages.MyquotesPage;

public class MyquotesTest {

	static WebDriver driver;
	MyquotesPage myquotesPage;

	@BeforeClass
	public void beforeMethod() {
		myquotesPage = PageFactory.initElements(LoginTest.driver, MyquotesPage.class);
	}

	@Test(priority = 1)
	public void enterintomyQuotes() throws InterruptedException {
		MyquotesPage.enterintomyQuotes();
	}
	
	@Test(priority = 2)
	public void myquotechoosefilters() throws InterruptedException {
		MyquotesPage.myquotechoosefilters();
	}
	
	
	
	@Test(priority = 4)
	public void sorting() throws InterruptedException {
		MyquotesPage.sorting();
	}
	
	@Test(priority = 3)
	public void print() throws AWTException, InterruptedException {
		MyquotesPage.print();
	}
	
}
	