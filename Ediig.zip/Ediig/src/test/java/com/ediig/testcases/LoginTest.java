package com.ediig.testcases;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ediig.pages.HomePageLogin;
import com.ediig.utility.BrowserFactory;
import com.ediig.utility.Constant;
import com.ediig.utility.ExcelUtil;

@Test
public class LoginTest {
	public static WebDriver driver;
	HomePageLogin login;

	@BeforeSuite
	public void BrowserLanuch() throws Exception {
		// driver = BrowserFactory.getBrowser("Firefox");
		driver = BrowserFactory.getBrowser("Chrome");
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		driver.get(Constant.URL);
		login = PageFactory.initElements(driver, HomePageLogin.class);
		ExcelUtil.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Sheet1");
		//LoginPage.loginwithValidEdiig();
		Reporter.log("Logged in to ediig successfully");
	}
	
	@Test
	public void invalidateValidData() throws Exception {
		HomePageLogin.loginwithinValidEdiig();
		HomePageLogin.verifyInvaliddetails();
	}
	
	@Test
	public void validateValidData() throws Exception {
		HomePageLogin.loginwithValidEdiig();
		HomePageLogin.verifyingLoginSuccesssfully();
		
	}
	
	@AfterSuite
	public void BrowserClose() {
		driver.quit();
	}

//	@BeforeSuite
//	public void loginEdiig() throws Exception {
//		ExcelUtil.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Sheet1");
//		LoginPage.loginToEdiig();
//		Reporter.log("Logged in to ediig successfully");
//	}
//
//	@BeforeSuite
//	public void verifyElementUpOnLogin() throws Exception {
//		//LoginPage.verifyElementPresent();
//		Reporter.log("Logged in to ediig successfully and the element is present up on login");
	//}
	

}








