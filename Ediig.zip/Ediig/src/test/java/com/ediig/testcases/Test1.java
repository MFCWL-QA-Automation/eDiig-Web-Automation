package com.ediig.testcases;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ediig.pages.AllLiveEventsPage;
import com.ediig.utility.BrowserFactory;

public class Test1 extends BrowserFactory{

}
