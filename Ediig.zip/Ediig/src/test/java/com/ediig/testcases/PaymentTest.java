package com.ediig.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ediig.pages.Paymentpage;

public class PaymentTest {

	static WebDriver driver;
	Paymentpage paymentpage;

	@BeforeClass
	public void beforeMethod() {
		paymentpage = PageFactory.initElements(LoginTest.driver, Paymentpage.class);
	}
	
	@Test(priority=1)
	public void enterintopayment() throws InterruptedException {
		Paymentpage.enterintopayment();	
	}
	
	@Test(priority=2)
	public void renewbuyerid() throws InterruptedException  {
		Paymentpage.renewbuyerid();
	}
	
	
//	@Test(priority=3)
	public void topupEMD() throws InterruptedException {
		Paymentpage.topupEMD();
	}
	
	//@Test(priority=4)
	public void paybuyerfee() {
		Paymentpage.paybuyerfee();
	}
	
	//@Test(priority=5)
	public void makevehiclepayment() {
		try {
			Paymentpage.makevehiclepayment();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
