package com.ediig.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ediig.pages.SaleCalenderPage;

public class SaleCalenderTest {
	WebDriver driver;
	SaleCalenderPage salecalenderpage;

	@BeforeClass
	public void beforeMethod() {
		salecalenderpage = PageFactory.initElements(LoginTest.driver, SaleCalenderPage.class);
	}

	@Test
	public void enterIntoSaleCalendar() throws Exception {
		SaleCalenderPage.clickSaleCalender();
		Thread.sleep(2000);
		Reporter.log("clicked on sale calendar icon");
	}

	@Test
	public void saleCalenderFlow() throws InterruptedException {
		salecalenderpage.chooseLocationDropdown();
		salecalenderpage.chooseCategoryDropdown();
		salecalenderpage.chooseSellerName();
		salecalenderpage.chooseAuctiontype();
		
		Thread.sleep(2000);
		
		
		salecalenderpage.filterDataLocationValidation();
		salecalenderpage.filterDataCategoryValidation();
		salecalenderpage.filterDataSellerNameValidation();
		
	
		salecalenderpage.sortingdata();
		
		resetAll();
	}

	@Test
	public void saleListDownload() throws InterruptedException {
		salecalenderpage.saleListDownload();
	}
	

	@Test
	public void showingEntries() throws InterruptedException {
		salecalenderpage.showingentries();
		// driver.navigate().back();
	}

	private void resetAll() {
		salecalenderpage.resetAll();
		System.out.println("reset all filters");
	}
}

/*
 * @Test public void downloadFileValidation() {
 * salecalenderpage2.downloadFileValidation();
 * System.out.println("sale list downloaded"); }
 */

/*
 * @Test public void selectcategory() throws InterruptedException {
 * salecalenderpage2.chooseCategoryDropdown();
 * System.out.println("choose ctagerory "); Thread.sleep(5000);
 * 
 * }
 * 
 * @Test public void selectsellerName() throws InterruptedException {
 * salecalenderpage2.chooseSellerName();
 * System.out.println("choose sellerName "); Thread.sleep(5000); }
 * 
 * @Test public void selectAuctionType() throws InterruptedException {
 * salecalenderpage2.chooseAuctiontype(); System.out.println("Auction type ");
 * Thread.sleep(5000); }
 * 
 */
