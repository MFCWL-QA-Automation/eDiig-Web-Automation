package com.ediig.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ediig.pages.AllLiveEventsPage;
import com.ediig.pages.AllLiveEventsPage2;

public class AllLiveEventsTest_old {

	static WebDriver driver;
	AllLiveEventsPage2 allLiveEventsPage2;
	String quoteNowText = "eventsartus";

	@BeforeClass
	public void beforeMethod() {
		allLiveEventsPage2 = PageFactory.initElements(LoginTest.driver, AllLiveEventsPage2.class);
	}

	@Test
	public void alllivechooseSellerName() throws InterruptedException {
		AllLiveEventsPage2.alllivechooseSellerName();
	}

	@Test
	public void alllivechooseLocation() throws InterruptedException {
	AllLiveEventsPage2.alllivechooseLocationDropdown();
	}

	
	public void alllivechooseEventtype() throws InterruptedException {
		AllLiveEventsPage2.alllivechooseEventType();
	}

	@Test
	public void showingentriesno() throws InterruptedException {
		AllLiveEventsPage2.showingentriesno();
	}
	
	@Test
	public void openliveevent() {
		try {
			AllLiveEventsPage2.openliveEvent();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	  public void biddingDisplayOptions() throws Exception {
		AllLiveEventsPage2.biddingDisplayOptions();
	 }
}
