package com.ediig.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ediig.pages.ContactusPage;



public class ContactusTest {
	
	static WebDriver driver;
	ContactusPage contactusPage;

	@BeforeClass
	public void beforeMethod() {
		contactusPage = PageFactory.initElements(LoginTest.driver, ContactusPage.class);
	}
	
	@Test
	public void entercontactus() throws InterruptedException {
		ContactusPage.contactus();
	}
	
	@Test
	public void validatecontactus() throws InterruptedException {
		ContactusPage.validatecontactus();
		
	}

}
