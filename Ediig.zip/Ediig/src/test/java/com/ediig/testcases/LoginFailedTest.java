package com.ediig.testcases;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import com.ediig.utility.BrowserFactory;
import com.ediig.utility.Constant;
import com.ediig.utility.ExcelUtil;

@Test
public class LoginFailedTest {
	
		public WebDriver driver;
	//	LoginFailledPage loginFailed;

		@BeforeSuite
		public void beforeMethod() {

			driver = BrowserFactory.getBrowser("Chrome");
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
			driver.get(Constant.URL);
			// loginFailed = PageFactory.initElements(driver, LoginFailledPage.class);
		}

		@BeforeSuite
		public void loginEdiig() throws Exception {
			ExcelUtil.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Sheet1");
		//	LoginFailledPage.loginToEdiig();
			System.out.println("login failed");
			Reporter.log("Logged in to ediig failed");
		}

		@BeforeSuite
		public void verifyLogin() throws Exception {
			System.out.println("invalid user name and password ");
			Reporter.log("Logged in to ediig successfully and the element is present up on login");
		}

	}

