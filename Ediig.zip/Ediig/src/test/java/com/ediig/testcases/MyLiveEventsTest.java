package com.ediig.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ediig.pages.MyLiveEventsPage;

public class MyLiveEventsTest   {

	static WebDriver driver;
	MyLiveEventsPage myLiveEventsPage;

	@BeforeClass
	public void beforeMethod() {
		myLiveEventsPage = PageFactory.initElements(LoginTest.driver, MyLiveEventsPage.class);
	}
	

	@Test(priority = 1)
	public void choosefilters() throws InterruptedException {
		MyLiveEventsPage.choosefilters();
	}
	
	
	@Test(priority = 2)
	public void quotenow() throws InterruptedException {
		MyLiveEventsPage.quotenow();
		// MyLiveEventsPage.resetall();
	}
	
	@Test(priority = 3)
	public void invalidamount() throws InterruptedException {
		MyLiveEventsPage.invalidamount();
	}
	
	@Test(priority = 4)
	public void multiquote() throws InterruptedException {
		MyLiveEventsPage.multiQuotes();
	}
	
	@Test (priority = 5)
	public void addtowatchlist() throws InterruptedException {
		MyLiveEventsPage.addToWatchlist();
	}
	
	@Test (priority = 6)
	public void MyLiveEventpageEtquote() throws InterruptedException{
		MyLiveEventsPage.MyLiveEventEtquotepage();
	}
}
