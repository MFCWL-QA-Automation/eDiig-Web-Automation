package com.ediig.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ediig.pages.AllLiveEventsPage;
import com.ediig.pages.LoginAdminEdiingPage;
import com.ediig.utility.BrowserFactory;
import com.ediig.utility.Constant;
import com.ediig.utility.ExcelUtil;

public class LoginAdminEdiigTest extends BrowserFactory{
	
	//public WebDriver driver;
	LoginAdminEdiingPage loginAdminEdiig;
	AllLiveEventsPage allLiveEventsPage;
	String sUserName;
	String sPassword;
	Actions actions;

//@Test
//public void beforeMethod() {
//
//	driver = BrowserFactory.getBrowser("Chrome");
//	driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
//	driver.get(Constant.URL);
//	loginAdminEdiig = PageFactory.initElements(driver, LoginAdminEdiingPage.class);
//}

@Test
public void loginEdiig() throws Exception {
	ExcelUtil.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Sheet1");
	//navigateToAdmin(Constant.URLAdmin);
	driver.navigate().to(Constant.URLAdmin);
	//approved();
	Thread.sleep(2000);
//	driver.navigate().back();
//	driver.navigate().back();
	//navigateToAppln(Constant.URL);
	//LoginAdminEdiig.loginToEdiig();
	//LoginAdminEdiingPage.loginadminEdiig();
	
	
	ExcelUtil.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Sheet1");
	// loginToEdiigAdmin();
	// Thread.sleep(2000);
	// }
	// public void loginToEdiigAdmin() throws Exception {
	sUserName = ExcelUtil.getCellData(10, 1);// give correct numbers
	sPassword = ExcelUtil.getCellData(10, 2);
	driver.findElement(By.xpath("//input[@type='text']")).sendKeys(sUserName);
	driver.findElement(By.xpath("//input[@type='password']")).sendKeys(sPassword);
	Thread.sleep(1000);
	System.out.println("login admin");
	driver.findElement(By.xpath("//button[@type='button']")).click();
	Thread.sleep(1000);
	// btnLogin.click();
	driver.findElement(By.xpath("//span[text()='buyer administration']")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//a[text()='buyer request to permission']")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("(//tbody//tr/td[4])[2]")).click();
	
	//System.out.println("clicked first community name ");
	//allLiveEventsPage.tabKeyPress(3);
	/*
	 * driver.findElement(By.xpath("//i[@class='fa fa-check']")).click();
	 * Thread.sleep(1000); driver.findElement(By.id("Value")).sendKeys(Keys.ENTER);
	 * System.out.println("clicked ok"); //actions.keyDown(Keys.ENTER);
	 * Thread.sleep(1000); driver.findElement(By.id("Value")).sendKeys(Keys.ENTER);
	 * System.out.println("clicked ok"); //actions.keyDown(Keys.ENTER);
	 * Thread.sleep(1000);
	 * driver.findElement(By.xpath("  (//*[text()='Inspected! Proceed to Bid'])[2]")
	 * ).click();
	 * 
	 * driver.findElement(By.xpath("//strong[text()='Approved']")).click();
	 */
	
	//allLiveEventsPage.tabKeyPress(3);
	
	//driver.findElement(By.xpath("//i[@class='fa fa-check']")).click();
	
	/*
	 * WebElement approveelement =
	 * driver.findElement(By.xpath("//i[@class='fa fa-check']")); JavascriptExecutor
	 * js = (JavascriptExecutor)driver;
	 * js.executeScript("arguments[0].scrollIntoView()", approveelement);
	 * approveelement.click();
	 */
	/*
	 * Alert approveok = driver.switchTo().alert(); String alertText =
	 * approveok.getText(); System.out.println("Alert data: " + alertText);
	 * approveok.accept(); Thread.sleep(3000);
	 */
	
	/*
	 * driver.findElement(By.xpath("(//*[text()='Inspected! Proceed to Bid'])[2]")).
	 * click(); actions.keyDown(Keys.ENTER); actions.keyDown(Keys.ENTER);
	 * driver.findElement(By.xpath("//strong[text()='Approved']")).isDisplayed();
	 * System.out.println("123344555"); Thread.sleep(2000);
	 */
	  navigateToAppln(Constant.URL);
	

}
//
//@BeforeSuite
//public void verifyLogin() throws Exception {
//	System.out.println("logged into ediig admin  ");
//	Reporter.log("Logged in to ediig successfully and the element is present up on login");
//}
//
//public void buyerAdministration() throws InterruptedException {
//	LoginAdminEdiingPage.buyerAdministration();
//}



public void navigateToAdmin(String url) {
	driver.navigate().to(url);
}

public void navigateToAppln(String applnurl) {
	driver.navigate().to(applnurl);
}


/*public void approved() throws Exception{
	ExcelUtil.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Sheet1");
	// loginToEdiigAdmin();
	// Thread.sleep(2000);
	// }
	// public void loginToEdiigAdmin() throws Exception {
	sUserName = ExcelUtil.getCellData(10, 1);// give correct numbers
	sPassword = ExcelUtil.getCellData(10, 2);
	driver.findElement(By.xpath("//input[@type='text']")).sendKeys(sUserName);
	driver.findElement(By.xpath("//input[@type='password']")).sendKeys(sPassword);
	System.out.println("login admin");
	driver.findElement(By.xpath("//button[@type='button']")).click();
	// btnLogin.click();
	driver.findElement(By.xpath("//span[text()='buyer administration']")).click();
	Thread.sleep(1000);
	driver.findElement(By.xpath("//a[text()='buyer request to permission']")).click();
	Thread.sleep(1000);
	System.out.println("clicked first community name ");
	
	
	 * driver.findElement(By.xpath("//tbody//tr/td[4]")).click();
	 * actions.keyDown(Keys.TAB); actions.keyDown(Keys.TAB);
	 * actions.keyDown(Keys.TAB);
	 
	 
	driver.findElement(By.xpath("//i[@class='fa fa-check']")).click();
	Thread.sleep(1000);
	driver.findElement(By.id("Value")).sendKeys(Keys.ENTER);
	System.out.println("clicked ok");
	//actions.keyDown(Keys.ENTER);
	Thread.sleep(1000);
	driver.findElement(By.id("Value")).sendKeys(Keys.ENTER);
	System.out.println("clicked ok");
	//actions.keyDown(Keys.ENTER);
	Thread.sleep(1000);
	driver.findElement(By.xpath("  (//*[text()='Inspected! Proceed to Bid'])[2]")).click();
	
	driver.findElement(By.xpath("//strong[text()='Approved']")).click();
	
}
*/
}