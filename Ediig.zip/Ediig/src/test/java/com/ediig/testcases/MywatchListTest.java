package com.ediig.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.ediig.pages.MyWatchListPage;

public class MywatchListTest {

	static WebDriver driver;
	MyWatchListPage myWatchListPage;

	@BeforeClass
	public void beforeMethod() {
		myWatchListPage = PageFactory.initElements(LoginTest.driver, MyWatchListPage.class);
		
	}
	
	@Test(priority = 1)
	public void entertomywatchlist() throws InterruptedException {
		MyWatchListPage.entertomywatchlist();
	}

	@Test
	public void myWatchlistChoosefilters() throws InterruptedException {
		MyWatchListPage.myWatchlistChoosefilters();
	}

	@Test(priority = 2)
	public void myWatchlistdded() throws InterruptedException {
		MyWatchListPage.myWatchlistdded();
	}
	@Test(priority = 3)
	public void myWatchquotenow() throws InterruptedException {
		MyWatchListPage.myWatchquotenow();
	}

	@Test(priority = 5)
	public void mywatchinvalidamount() throws InterruptedException {
		MyWatchListPage.mywatchinvalidamount();
	}
	@Test(priority = 4)
	public void removefromwatchlist() throws InterruptedException {
		MyWatchListPage.removefromwatchlist();
	}
}
