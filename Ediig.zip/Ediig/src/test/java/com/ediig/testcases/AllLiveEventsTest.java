package com.ediig.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ediig.pages.AllLiveEventsPage;

public class AllLiveEventsTest   {

	static WebDriver driver;
	AllLiveEventsPage allLiveEventsPage;
	String quoteNowText = "eventsartus";

	
	@BeforeClass
	public void beforeMethod() {
		allLiveEventsPage = PageFactory.initElements(LoginTest.driver, AllLiveEventsPage.class);
	}
	
	@Test(priority = 1)
	public void clickOnAlllivevents() throws InterruptedException {
		AllLiveEventsPage.clickOnAlllivevents();
		
	}

	@Test(priority = 4)
	public void alllivechooseSellerName() throws InterruptedException {
	allLiveEventsPage.alllivechooseSellerName();
	}

	@Test(priority = 3)
	public void alllivechooseLocation() throws InterruptedException {
	AllLiveEventsPage.alllivechooseLocation();
	}

	@Test(priority = 2)
	public void alllivechooseEventtype() throws InterruptedException {
		allLiveEventsPage.alllivechooseEventType();
	}

	@Test(priority = 5)
	public void showingentriesno() throws InterruptedException {
		allLiveEventsPage.showingentriesno();
	}
	
	
	@Test(priority = 6)
	public void openliveevent() throws InterruptedException {
			allLiveEventsPage.openliveevent();
		}
	
	
	@Test(priority = 7)
	  public void eventStatus() throws Exception {
		System.out.println("checking event status" );
		allLiveEventsPage.eventStatus(); }
}
