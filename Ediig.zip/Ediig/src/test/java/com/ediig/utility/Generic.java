package com.ediig.utility;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import junit.framework.Assert;

public class Generic {
	
	
	public static void elementFound(WebElement element) {
		boolean isStatus = element.isDisplayed();
		Assert.assertTrue("Element is displayed", isStatus);
	}
	
	public static void elementClcik(WebElement element) {
		element.click();
	}
	
	
	public static void selectDropdownByText(WebElement element, int index) {
		Select oSelect = new Select(element);
		List<WebElement> dropDownItems = oSelect.getOptions();
		int size = dropDownItems.size();
		for(int i=0;i<size;i++) {
			String options = dropDownItems.get(i).getText();
			oSelect.selectByIndex(index);
		}
	}

}
