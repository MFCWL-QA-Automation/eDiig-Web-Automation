package com.ediig.utility;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class BrowserFactory {
	
	
	private static Map<String, WebDriver>drivers = new HashMap<String, WebDriver>();
	public static WebDriver driver;

	public static WebDriver getBrowser(String browserName) {
		
		
		
		switch(browserName) {
		case "Firefox":
			driver = drivers.get("Firefox");
			if(driver==null) {
			System.setProperty("webdriver.gecko.driver", "C:\\firefox_driver\\geckodriver.exe");
			driver = new FirefoxDriver();
			drivers.put("Firefox", driver);
		}
		break;
		
		case "IE":
			driver = drivers.get("IE");
			if(driver==null) {
			System.setProperty("webdriver.ie.driver","C:\\Users\\mfcwl\\Ediig\\Drivers\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			drivers.put("IE", driver);
		}
		break;
		case "Chrome":
			driver = drivers.get("Chrome");
			if(driver==null) {
			System.setProperty("webdriver.chrome.driver","C:\\Users\\mfcwl\\Ediig\\Drivers\\chromedriver.exe");
				driver = new ChromeDriver();
				drivers.put("Chrome", driver);
				driver.get("https://test.ediig.com");
				driver.manage().window().maximize();
		}
			break;
		}
			return driver;
		}
	
	
	public static void closeAllDriver() {
		for (String key : drivers.keySet()) {
			drivers.get(key).close();
			drivers.get(key).quit();
		}
	}
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * public static WebDriver startApplication(WebDriver driver,String
	 * browserName,String appURL) { if(browserName.equals("Chrome")) {
	 * System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
	 * driver=new ChromeDriver(); driver.manage().timeouts().pageLoadTimeout(20,
	 * TimeUnit.SECONDS); } else if(browserName.equals("Firefox")) {
	 * 
	 * System.setProperty("webdriver.gecko.driver", "./Drivers/geckodriver.exe");
	 * driver=new FirefoxDriver(); driver.manage().timeouts().pageLoadTimeout(20,
	 * TimeUnit.SECONDS); } else if(browserName.equals("IE")) {
	 * System.setProperty("webdriver.IE.driver", "./drivers/IEdriver.exe");
	 * driver=new InternetExplorerDriver();
	 * driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS); } else {
	 * System.out.println("do nor support this browser"); }
	 * driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
	 * driver.manage().window().maximize(); driver.get(appURL);
	 * driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); return
	 * driver; }
	 * 
	 * public static void quitBrowser(WebDriver driver) {
	 * 
	 * }
	 * 
	 * 
	 */
