package com.ediig.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtil {
	  private static XSSFSheet ExcelWSheet;
      private static XSSFWorkbook ExcelWBook;
      private static XSSFCell Cell;
      private static XSSFRow Row;
      
      static List<String> records;
      
      public static void setExcelFile(String Path, String SheetName) throws Exception{

    	  try {
    	FileInputStream excelFile = new FileInputStream("C:\\Users\\mfcwl\\Ediig\\Data\\Ediig_data_updated.xlsx");
    	// Access the required test data sheet
    	ExcelWBook = new XSSFWorkbook(excelFile);
    	ExcelWSheet = ExcelWBook.getSheet(SheetName);

    	} catch (Exception e){

    	throw (e);

    	}
    	}

    	public static String getCellData(int RowNum, int ColNum) throws Exception{
    	      try{
    	          Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
    	          String CellData = Cell.getStringCellValue();
    	          return CellData;
    	          }catch (Exception e){
    	return"";

    	          }
    	}
      
	//This method is to set the File path and to open the Excel file, Pass Excel Path and Sheetname as Arguments to this method
	/*
	 * public static void setExcelFile(String Path,String SheetName) throws
	 * Exception {
	 * 
	 * 
	 * Stream<String> data =
	 * Files.lines(Paths.get("C:\\Users\\mfcwl\\Ediig\\Data\\Ediig_usersdata.csv"));
	 * data.forEach(line -> { // open web page records =
	 * Arrays.asList(line.split(",")); sUserName = records.get(0); sPassword =
	 * records.get(1); }); }
	 * 
	 * public static String getCellData(int i, int j) { // TODO Auto-generated
	 * method stub return null; }
	 */
    }

        


    
	    

	
