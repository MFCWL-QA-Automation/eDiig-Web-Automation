package com.ediig.utility;

import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ediig.testcases.LoginTest;

public class Solvent {
	
	public WebDriver driver;
	
	public Solvent(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public Solvent() {
		
		
	}
	
	public void elementClick(WebElement element) {
		element.click();
	}
	
	public void waitForElementToBeClickable(WebElement element){
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	public int getRandomNumber(int min, int max){
		return new Random().nextInt(max - min + 5)+1;
	}
	
	public String getText(WebElement element){
		return element.getText();
	}
	
	public void acceptAlert(){
		Alert alert = driver.switchTo().alert();
        alert.accept();
	}
	
	/*
	 * public String getEventStatus(){ return executeJS(); }
	 */
	
	public String eventStatusGetting(){
		/*
		 * driver=LoginTest.driver; JavascriptExecutor js = (JavascriptExecutor)driver;
		 * Object script = js.
		 * executeScript("return document.getElementsByClassName('col-sm-5 p-0 col-12')[0].innerText;"
		 * ); //Object script = js.
		 * executeScript("return document.getElementsByXpath('//button[@type='submit']').innerText;"
		 * ); System.out.println(script.toString()); return script.toString();
		 */
		driver=LoginTest.driver;
		String eventStatus = driver.findElement(By.xpath("//button[@type='submit']")).getText();
		return eventStatus;
		
	}
	
	public void openNewWindowTab(){
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.open();");
	}
	
	
	public void switchToNewlyWIndow(String title){
		Set<String> window = driver.getWindowHandles();
		Iterator<String> windows = window.iterator();//.next();
		while (windows.hasNext()){
			driver.switchTo().window(windows.next());
			if(driver.getTitle().contains(title))
				break;
		}
	}
	
	public void reloadPage(){
		driver.get(driver.getCurrentUrl());
	}
	
	public void switchBetweenTabs(){
		Actions actions = new Actions(driver);
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.TAB).build().perform();
	}
}

