package com.ediig.utility;

public class Constant {
	public static final String URL = "https:test.ediig.com";
	public static final String Username = "testqa";
	public static final String Password = "Test@123";
	public static final String Path_TestData = "C:\\Users\\mfcwl\\Ediig\\Data";
	public static final String File_TestData = "Ediig_data.xlsx";
	public static final String URLAdmin = "http://staging.admin.ediig.com";

}
